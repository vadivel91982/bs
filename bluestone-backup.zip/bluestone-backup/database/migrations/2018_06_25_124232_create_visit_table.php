<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVisitTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('visit', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id');
            $table->string('room_no');
            $table->string('name', 250);
            $table->string('email')->unique();
            $table->integer('phone');
            $table->integer('status');
            $table->string('avatar', 255);
            $table->string('address', 255);
            $table->string('company', 100);
            $table->string('vehicle', 150);
            $table->enum('proof_type', ['aadhaar', 'driving', 'others']);
            $table->string('proof', 255);
            $table->string('purpose', 100);
            $table->integer('adult');
            $table->integer('child');
            $table->dateTime('arrival_date');
            $table->dateTime('departure_date');
            $table->string('frgn_nationality', 100);
            $table->date('frgn_dob');
            $table->string('frgn_passport', 255);
            $table->string('frgn_date_place', 255);
            $table->string('frgn_validity', 100);
            $table->string('frgn_local_address', 255);
            $table->enum('frgn_employed', ['1', '0']);
            $table->integer('ocpy_single');
            $table->integer('ocpy_double');
            $table->integer('room_type_ac');
            $table->integer('room_type_nonac');
            $table->integer('advance');
            $table->string('receipt_no');
            //$table->string('office_proof_attach', 255);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('visit');
    }
}
