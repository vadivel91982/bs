<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Visit extends Model
{
    use Notifiable;

    protected $table = 'visit';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = array('id', 'user_id', 'name', 'email', 'phone', 'status', 'avatar', 'address', 'company', 'vehicle', 'proof_type', 'proof', 'purpose', 'adult', 'child', 'arrival_date', 'departure_date', 'frgn_nationality', 'viist_frgn_dob', 'frgn_passport', 'frgn_date_place','frgn_validity', 'frgn_local_address', 'frgn_employed', 'office_ocpy_single', 'office_ocpy_double', 'office_room_type', 'office_proof_attach', 'created_at', 'updated_at');

    // public function setArrivalDateAttribute( $value ) {
    //     $this->attributes['arrival_date'] = \Carbon::createFromFormat('Y-m-d H:i:s', $value)->format('F j, Y @ g:i A');
    //    // dd( (new Carbon($value))->format('Y-m-d H:i:s'));
    //     //$this->attributes['arrival_date'] = (new Carbon($value))->format('Y-m-d H:i:s');

        
    // }

    public function billings() 
    {
        return $this->hasMany('App\Billing');
    }

}
