<?php

namespace App\Http\Controllers\Visit;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\VisitUser;
use App\Http\Requests\Room AS RoomRequest;
use App\Visit;
use App\User;
use App\Billing;
use App\Room;
use PDF;
use Carbon\Carbon;
use Yajra\Datatables\Datatables;
use Illuminate\Support\Facades\Auth;

class VisitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(RoomRequest $request)
    {   
        $availableRooms = implode(",", $request->room);
        return \View::make('visit.create')->with('availableRooms', $availableRooms);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(VisitUser $request)
    {        
        //save user table
        $user = new User;

        $userDetails = $user->where('email', $request->email)->orWhere('phone', $request->mobile)->get(); 


        // user avatqar
        $encoded_data = $request->avatar;
        $binary_data = base64_decode($encoded_data);

        // save to server (beware of permissions)
        $userAvatar = 'avatar-'.uniqid().".jpeg";

        $userResult = file_put_contents( base_path() .'/public/images/customer/'. $userAvatar, $binary_data );
        if (!$userResult) die("Could not save image!  Check file permissions.");


        // user proof
        $proofEncodedData = $request->user_proof;
        $proofBinaryData = base64_decode($proofEncodedData);

        // save to server (beware of permissions)
        $userProof = 'proof-'.uniqid().".jpeg";

        $userResult = file_put_contents( base_path() .'/public/images/proof/'. $userProof, $proofBinaryData );
        if (!$userResult) die("Could not save image!  Check file permissions.");

        $user->role_id = 3;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->mobile;
        $user->avatar = $userAvatar;
        $user->status = 1;
        $user->address = $request->address;
        $user->company = $request->company;
        $user->vehicle = $request->vehicle;
        $user->proof_type = $request->proof_type;
        $user->proof = $request->proof;

        $user->save();

        //save visit table
        $visit = new Visit;
        $visit->user_id = $user->id;
        $visit->admin_id = Auth::user()->id;
        $visit->name = $request->name;
        $visit->email = $request->email;
        $visit->phone = $request->mobile;
        $visit->avatar = $userAvatar;
        $visit->status = 1;
        $visit->address = $request->address;
        $visit->company = $request->company;
        $visit->vehicle = $request->vehicle;
        $visit->proof_type = $request->proof_type;
        $visit->proof = $request->proof;
        $visit->room_no = $request->room_no;
        $visit->purpose = $request->purpose;
        $visit->adult = $request->adult;
        $visit->child = $request->child;
        $visit->arrival_date = (new Carbon($request->arrival_date))->format('Y-m-d H:i:s');

        if($request->frgn_passport) 
        {
            $visit->frgn_nationality = $request->frgn_nationality;
            $visit->frgn_dob = $request->frgn_dob;
            $visit->frgn_passport = $request->frgn_passport;
            $visit->frgn_date_place = $request->frgn_date_place;
            $visit->frgn_validity = $request->frgn_validity;
            $visit->frgn_local_address = $request->frgn_local_address;
            $visit->frgn_employed = $request->frgn_employed;
        }
    
        $visit->ocpy_single = $request->ocpy_single;
        $visit->ocpy_double = $request->ocpy_double;
        $visit->room_type_ac = $request->room_type_ac;
        $visit->room_type_nonac = $request->room_type_nonac;
        $visit->advance = $request->advance;
        $visit->receipt_no = $request->receipt_no;

        $visit->save();

        $visitDetails = Visit::find($visit->id);
        $pdf = PDF::loadView('visit.checkinpreview', compact('user'));
        return $pdf->download('check-in-form.pdf');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $visit = Visit::find($id);
        return \View::make('visit.edit')->with('visit', $visit);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(VisitUser $request, $id)
    {
        //update user table
        $user = new User;
        $user->where('id', $request->user_id)->update([
            'role_id' => 3,
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->mobile,
            'avatar' => '',
            'status' => 1,
            'address' => $request->address,
            'company' => $request->company,
            'vehicle' => $request->vehicle,
            'proof_type' => $request->proof_type,
            'proof' => $request->proof
        ]);
        //$user->update();

        //update visit table
        $visit = new Visit;
        
        $visitField['user_id'] = $request->user_id;
        $visitField['admin_id'] = Auth::user()->id;
        $visitField['name'] = $request->name;
        $visitField['email'] = $request->email;
        $visitField['phone'] = $request->mobile;
        $visitField['avatar'] = '';
        $visitField['status'] = 1;
        $visitField['address'] = $request->address;
        $visitField['company'] = $request->company;
        $visitField['vehicle'] = $request->vehicle;
        $visitField['proof_type'] = $request->proof_type;
        $visitField['proof'] = $request->proof;
        $visitField['room_no'] = $request->room_no;
        $visitField['purpose'] = $request->purpose;
        $visitField['adult'] = $request->adult;
        $visitField['child'] = $request->child;
        $visitField['arrival_date'] = (new Carbon($request->arrival_date))->format('Y-m-d H:i:s');

        if($request->frgn_passport) 
        {
            $visitField['frgn_nationality'] = $request->frgn_nationality;
            $visitField['frgn_dob'] = $request->frgn_dob;
            $visitField['frgn_passport'] = $request->frgn_passport;
            $visitField['frgn_date_place'] = $request->frgn_date_place;
            $visitField['frgn_validity'] = $request->frgn_validity;
            $visitField['frgn_local_address'] = $request->frgn_local_address;
            $visitField['frgn_employed'] = $request->frgn_employed;
        }

        $visitField['ocpy_single'] = $request->ocpy_single;
        $visitField['ocpy_double'] = $request->ocpy_double;
        $visitField['room_type_ac'] = $request->room_type_ac;
        $visitField['room_type_nonac'] = $request->room_type_nonac;
        $visitField['advance'] = $request->advance;
        $visitField['receipt_no'] = $request->receipt_no;
        
        $visit->where('id', $id)->update($visitField);

        return redirect()->route('visit.list')->with('success', 'You have updated admin successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * Displays datatables front end view
     *
     * @return \Illuminate\View\View
     */
    public function getIndex()
    {
        return view('visit.index');
    }

    /**
     * Process datatables ajax request.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function visitData()
    {
        $visit = Visit::select(['id', 'receipt_no', 'name', 'email', 'phone', 'user_id', 'arrival_date'])->where('status', '1');
        //$visit = \App\Models\Visit::with('users')->get();
        return Datatables::of($visit)
            ->addColumn('action', function ($visit) {
                return '<div class="table-data-feature">
                    <button class="item" data-toggle="tooltip" data-placement="top" title="CheckOut">
                    <a href="checkout/'.$visit->id.'">
                        <i class="zmdi zmdi-shopping-cart-plus"></i>
                    </a>
                    </button>
                    <button class="item" data-toggle="tooltip" data-placement="top" title="View">
                        <i class="zmdi zmdi-eye"></i>
                    </button>
                    <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">                    
                        <a href="visit-edit/'.$visit->id.'">
                            <i class="zmdi zmdi-edit"></i>
                        </a>
                    </button>
                    <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                        <a href="visit-destroy/'.$visit->id.'">
                            <i class="zmdi zmdi-delete"></i>
                        </a>
                    </button>
                </div>';
            })
            
            ->editColumn('id', '{{$id}}')
            ->make(true);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showForm($id)
    {        
        $visit = Visit::with('billings')->find($id);
        /*echo "<pre>";
        print_r($visit);
        die;*/
        return \View::make('visit.checkout')->with('getData', $visit);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function createBilling(Request $request, $id)
    {          
        for($i = 0; $i < count($request->bs_price); $i++)
        {
            $billing = new Billing;
            $gstdividebytwo = $request->bs_gst[$i] / 2;
            $billing->visit_id = $id;
            $billing->service = $request->bs_service[$i];
            $billing->amount = $request->bs_price[$i];
            $billing->gst = $request->bs_gst[$i];
            $billing->cgst = $gstdividebytwo;
            $billing->sgst = $gstdividebytwo;
            $billing->total = $request->bs_total[$i];
            $billing->save();
        }

        echo "<pre>";
        print_r($_REQUEST);
        die;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function listRooms()
    {        
        
        $rooms = Room::get();
       // dd($rooms);
        return view('visit.room')->with('rooms', $rooms);
    }

        /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getRooms(RoomRequest $request){
        echo "<pre>";
        print_r($request->room);
        exit;

    }
    


}


