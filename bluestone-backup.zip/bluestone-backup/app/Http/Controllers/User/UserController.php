<?php

namespace App\Http\Controllers\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\CreateUser;
use App\Http\Requests\ChangePassword;
use App\User;
use Illuminate\Support\Facades\Hash;
use Yajra\Datatables\Datatables;
use Illuminate\Support\Facades\Auth;
use App;
use PDF;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return \View::make('user.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateUser $request)
    {
        //return User::create($request->all());
        $user = new User;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->password = bcrypt($request->password);
        $user->status = $request->status;
        $user->role_id = $request->role_id;

        if($request->hasFile('image')) {                                                                                                                  

            $file = $request->file('image');                                                                                                              
    
            $name = time() . '-' . $file->getClientOriginalName();                                                                                          
            $user->avatar = $name;
            $file->move(
                base_path() . '/public/images/customer/', $name
            );                                                                                                   
        }

        $user->save();

        return redirect()->route('account.create')->with('success', 'You have created admin successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $users = User::find($id);
        //dd($users);
        return \View::make('user.edit')->with('user', $users);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CreateUser $request, $id)
    {
        $user = User::find($id);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->status = $request->status;
        $user->role_id = $request->role_id;

        // $imageName = $user->id . '.' . 
        // $request->file('image')->getClientOriginalExtension();

        // $request->file('image')->move(
        //     base_path() . '/public/images/customer/', $imageName
        // );

        if($request->hasFile('image')) {                                                                                                                  

            $file = $request->file('image');                                                                                                              
    
            $name = time() . '-' . $file->getClientOriginalName();                                                                                          
            $user->avatar = $name;
            $file->move(
                base_path() . '/public/images/customer/', $name
            );                                                                                                   
        }
        $user->update();
        return redirect()->route('account.list')->with('success', 'You have updated admin successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::find($id)->delete();
        return redirect()->route('account.list')->with('success', 'You have deleted user successfully');
    }

    /**
     * Displays datatables front end view
     *
     * @return \Illuminate\View\View
     */
    public function getIndex()
    {
        return view('user.index');
    }

    /**
     * Process datatables ajax request.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function anyData()
    {
        $users = User::select(['id', 'name', 'email', 'phone', 'created_at', 'status'])->where('id', '!=' , Auth::user()->id);
        return Datatables::of($users)
            ->addColumn('action', function ($users) {
                return '<a href="edit/'.$users->id.'" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> Edit</a>
                <a href="destroy/'.$users->id.'" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-delete"></i> Delete</a>';
            })
            ->editColumn('id', '{{$id}}')
            ->editColumn('status', function ($users) {
                return ($users->status == '1')? 'Active': 'Inactive';
            })
            ->make(true);

        //return Datatables::of(User::query())->make(true);
    }

    /**
     * Show the change password page
     *
     * @param  null
     * @return display view file
     */


    public function changePassword()
    {
        return \View::make('user.change-password');
    }


        /**
     * Show the change password page
     *
     * @param  request
     * @return 
     */

    public function changePasswordStore(ChangePassword $request)
    {
        if (!(Hash::check($request->get('currentPassword'), Auth::user()->password))) {
            // The passwords matches
            return redirect()->back()->with("error","Your current password does not matches with the password you provided. Please try again.");
        }
 
        if(strcmp($request->get('currentPassword'), $request->get('newPassword')) == 0){
            //Current password and new password are same
            return redirect()->back()->with("error","New Password cannot be same as your current password. Please choose a different password.");
        }
 
        //Change Password
        $user = Auth::user();
        $user->password = bcrypt($request->get('newPassword'));
        $user->save();
 
        return redirect()->back()->with("success","Password changed successfully !");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function profile()
    {
        //$user = User::find(Auth::user()->id);
        //$pdf = PDF::loadView('user.profile', compact('user'));
        //return $pdf->download('profile.pdf');

       $user = User::find(Auth::user()->id);
        return \View::make('user.profile',compact('user','id'));
    }

}
