<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Visit;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $adminCount = User::where(['role_id' => 2, 'status' => 1])->count();
        $customerCount = User::where(['role_id' => 3, 'status' => 1])->count();
        $checkIn = Visit::whereDate('arrival_date', Carbon::today())->where('status', 1)->get();
        $checkOut = Visit::whereDate('departure_date', Carbon::today())->where('status', 2)->get();
        $totalCheckOut = Visit::whereDate('departure_date', Carbon::today())->where('status', 2)->count();
        return view('home', ['admin' => $adminCount, 'customer' => $customerCount,'checkin' => $checkIn, 'checkout' => $checkOut, 'totalcheckout' => $totalCheckOut]);
       // return view('home');
    }
}
