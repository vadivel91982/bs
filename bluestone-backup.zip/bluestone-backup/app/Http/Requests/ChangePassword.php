<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ChangePassword extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'currentPassword' => 'required',
            'newPassword' => 'required|different:currentPassword',
            'confirmPassword' => 'required|same:newPassword',

        ];
    }

    public function messages()
    {
        return [
            'currentPassword.required' => "Please enter the password",
            'newPassword.required' => trans('Please enter the new password'),
            'confirmPassword.required' => trans('Password mismatch'),
        ];
    }

}
