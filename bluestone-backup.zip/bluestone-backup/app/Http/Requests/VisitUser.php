<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Visit;


class VisitUser extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch($this->method())
        {
            case 'POST':
            {
                $rules = [
                    'room_no' => 'required',
                    'arrival_date' => 'required',
                    'email' => 'email',
                    'name' => 'required',
                    'mobile' => 'required|numeric|min:12',
                    'address' => 'required',
                    'purpose' => 'required',
                    'adult' => 'required|numeric',
                    'proof_type' => 'required',
                    'proof' => 'required',
                    'advance' => 'required|numeric',
                    'receipt_no' => 'required',
                    'frgn_nationality' => 'required_with:frgn_passport',
                    'frgn_dob' => 'required_with:frgn_passport',
                    'frgn_passport' => 'required_with:frgn_passport',
                    'frgn_date_place' => 'required_with:frgn_passport',
                    'frgn_validity' => 'required_with:frgn_passport',
                    'frgn_local_address' => 'required_with:frgn_passport',
                    'ocpy_single' => 'required_without:ocpy_double',
                    'room_type_ac' => 'required_without:room_type_nonac'
                ];
                return $rules;
            }
            case 'PATCH':
            {
                $rules = [
                    'room_no' => 'required',
                    'arrival_date' => 'required',
                    'email' => 'email',
                    'name' => 'required',
                    'mobile' => 'required|numeric|min:12',
                    'address' => 'required',
                    'purpose' => 'required',
                    'adult' => 'required|numeric',
                    'proof_type' => 'required',
                    'proof' => 'required',
                    'advance' => 'required|numeric',
                    'receipt_no' => 'required',
                    'frgn_nationality' => 'required_with:frgn_passport',
                    'frgn_dob' => 'required_with:frgn_passport',
                    'frgn_passport' => 'required_with:frgn_passport',
                    'frgn_date_place' => 'required_with:frgn_passport',
                    'frgn_validity' => 'required_with:frgn_passport',
                    'frgn_local_address' => 'required_with:frgn_passport',
                    'ocpy_single' => 'required_without:ocpy_double',
                    'room_type_ac' => 'required_without:room_type_nonac'
                ];
                return $rules;
            }
        }
    }

    public function messages()
    {
        return [
            'room_no.required' => 'The room no field is required',
            'arrival_date.required' => 'The date field is required',
            'name.required' => 'The name field is required',
            'mobile.required' => 'The mobile field is required',
            'address.required' => 'The address field is required',
            'purpose.required' => 'The purpose field is required',
            'adult.required' => 'The adult field is required',
            'proof_type.required' => 'The proof type field is required',
            'proof.required' => 'The proof field is required',
            'advance.required' => 'The advance field is required',
            'receipt_no.required' => 'The receipt field is required'
        ];
    }
}
