<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\User;

class CreateUser extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function rules()
    {
        switch($this->method())
        {
            case 'POST':
            {
                return [
                    'name' => 'required',
                    'email' => 'required|unique:users|email',
                    'phone' => 'required|numeric|min:10',
                    'password' => 'required|min:8',
                    'password_confirmation' => 'required|same:password|min:8',
                    'status' => 'required',
                    'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
                ];
            }
            case 'PATCH':
            {
                $user = User::find($this->id);
                $rules = [
                    'name' => 'required',
                    'email' => 'unique:users,email,'.$this->id.'|required|email',
                    'phone' => 'required|numeric|min:10',
                    'status' => 'required',
                    'image' => 'sometimes|required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
                ];

                /*if ($user->notHavingImageInDb()){
                    $rules['image'] = 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048';
                }*/
                return $rules;
            }

        }
        
    }
    public function messages()
    {
        return [
            'name.required' => 'The name field is required'
            
        ];
    }
}
