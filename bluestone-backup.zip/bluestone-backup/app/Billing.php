<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class Billing extends Model
{
    use Notifiable;

    protected $table = 'billing';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = array('id', 'visit_id', 'service', 'amount', 'gst', 'cgst', 'sgst', 'total', 'created_at', 'updated_at');

}
