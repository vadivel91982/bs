<meta charset="UTF-8">
<meta name="description" content="Bluestone">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Bluestone">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link id="page_favicon" href="../images/favicon.jpg" rel="icon" type="image/x-icon" />
<title>Blue Stone - <?php echo $__env->yieldContent('title'); ?></title>
<!--<link href="../../css/app.css" rel="stylesheet">
<link href="../../css/vendor.css" rel="stylesheet"> -->
    <!-- Fontfaces CSS-->
    <link href="../../theme/font-face.css" rel="stylesheet" media="all">
    <link href="../../theme/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="../../theme/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="../../theme/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="../../theme/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <link href="../../theme/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
    <!-- Vendor CSS-->
    <link href="../../theme/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="../../theme/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="../../theme/wow/animate.css" rel="stylesheet" media="all">
    <link href="../../theme/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="../../theme/slick/slick.css" rel="stylesheet" media="all">
    <link href="../../theme/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="../../theme/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <link href="../../theme/theme.css" rel="stylesheet" media="all">
    