<?php $__env->startSection('title'); ?>
    <?php echo e("User Profile"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<!-- DATA TABLE -->
		<div class="table-data__tool">
			<div class="table-data__tool-left">
				<h3 class="title-5">Profile</h3>
			</div>
			<div class="table-data__tool-right">
				<button onclick="javascript:location.href='<?php echo e(route('account.list')); ?>'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
		</div>
		
		
		<div class="card">
			<div class="card-header">
				<strong>User Profile</strong>
			</div>
			

			<div class="card-body card-block">
				<div class="row form-group">
					<div class="col col-md-12">
						<div class="proile-img">
							<img widht="100" height="100" src="/images/customer/<?php echo e(Auth::user()->avatar); ?>" alt="<?php echo e(Auth::user()->name); ?>" />
						</div>
						<table width="50%">
							<tr>
								<td width="23%"><h5><?php echo e(Form::label('name', 'Name'), ['class' => 'optionLabel']); ?></h5></td>
								<td width="2%">:</td>
								<td width="75%"><?php echo e($user->name); ?></td>
							</tr>
							<tr>
								<td><h5><?php echo e(Form::label('email', 'Email Address'), ['class' => 'optionLabel']); ?></h5></td>
								<td>:</td>
								<td><?php echo e($user->email); ?></td>
							</tr>
							<tr>
								<td><h5><?php echo e(Form::label('phone', 'Phone'), ['class' => 'optionLabel']); ?></h5></td>
								<td>:</td>
								<td><?php echo e($user->phone); ?></td>
							</tr>
						</table>
					</div>
				</div>
				
			</div>
			<div class="card-footer">				
            <?php echo link_to_route('account.edit', 'Edit', ['id' => Auth::user()->id], ['class' => 'btn btn-primary btn-lg']); ?>				
			</div>
		</div>
			
		<!-- END DATA TABLE -->
	</div>
</div>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>