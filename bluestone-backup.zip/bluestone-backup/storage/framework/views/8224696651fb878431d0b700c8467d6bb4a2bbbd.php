<?php $__env->startSection('title'); ?>
    <?php echo e("User Login"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<!-- DATA TABLE -->
		<div class="table-data__tool">
			<div class="table-data__tool-left">
				<h3 class="title-5">Edit Admin</h3>
			</div>
			<div class="table-data__tool-right">
				<button onclick="javascript:location.href='admin.html'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
		</div>
		
		
		<div class="card">
			<div class="card-header">
				<strong>Admin Form</strong>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<?php if(count($errors) > 0): ?>
					<div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<?php endif; ?>
				</div>
			</div>
			<?php echo e(Form::open(['method' => 'patch', 'route' => ['account.update',$user->id], 'files'=>'true'])); ?>

			<div class="card-body card-block">

				<div class="row form-group">
					<div class="col col-md-3">
					<?php echo e(Form::label('name', 'Name'), ['class' => 'optionLabel']); ?>

					</div>
					<div class="col-12 col-md-9">
					<?php echo e(Form::text('name', $user->name, ['class' => 'au-input au-input--full', 'placeholder' => 'Name'])); ?>

						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('email', 'Email Address'), ['class' => 'optionLabel']); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::text('email', $user->email, ['class' => 'au-input au-input--full', 'placeholder' => 'Email'])); ?>						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('phone', 'Phone'), ['class' => 'optionLabel']); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::text('phone', $user->phone, ['class' => 'au-input au-input--full', 'placeholder' => 'Phone'])); ?>

					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('status', 'Status', ['class' => 'optionLabel'])); ?>

					</div>
					<div class="col-12 col-md-9">						
						<?php $arr = ['' => 'Please select', '1' => 'Active', '2'=> 'Inactive']; ?>
						<select class="form-control" id='select' class='form-control' name="status">
							<?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($key); ?>" <?php if($user->status=== $key): ?> selected='selected' <?php endif; ?>> <?php echo e(strtoupper($item)); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('Upload Photo', 'Upload Photo', ['class' => 'form-control-label'])); ?>

					</div>
					<div class="col-12 col-md-9 image">						
						<?php if("/images/customer/<?php echo e($user->avatar); ?>"): ?>
							<img src="<?php echo e(URL::to('/')); ?>/images/customer/<?php echo e($user->avatar); ?>" width="100" height="100">							
						<?php else: ?>
							<p>No image found</p>
						<?php endif; ?>
						<br/>
						<br/>
						<input type="file" name="image" value="<?php echo e($user->avatar); ?>"/>
						<!-- <?php echo e(Form::file('image', ['id' => 'file-input', 'class' => 'form-control-file'])); ?> -->
					</div>
				</div>
				<?php echo e(Form::hidden('role_id', '2')); ?>

			</div>
			<div class="card-footer">				
				<!-- <i class="fa fa-dot-circle-o"></i> -->
				<?php echo e(Form::submit('Submit',array('class' => 'btn btn-primary btn-lg'))); ?>

				<!-- <i class="fa fa-ban"></i>  -->
				<?php echo e(Form::submit('Reset',array('class' => 'btn btn-danger btn-lg'))); ?>

			</div>
			<?php echo e(Form::close()); ?>

		</div>
			
		<!-- END DATA TABLE -->
	</div>
</div>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>