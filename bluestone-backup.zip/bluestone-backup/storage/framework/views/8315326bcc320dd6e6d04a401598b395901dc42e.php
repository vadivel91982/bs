<?php $__env->startSection('title'); ?>
    <?php echo e("Change Password"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<!-- DATA TABLE -->
		<div class="table-data__tool">
			<div class="table-data__tool-left">
				<h3 class="title-5">Change Password</h3>
			</div>
			<div class="table-data__tool-right">
				<button onclick="javascript:location.href='admin.html'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
		</div>
		
		
		<div class="card">
			<div class="card-header">
				<strong>Admin Form</strong>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<?php if(count($errors) > 0): ?>
					<div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<?php endif; ?>
				</div>
			</div>
			<?php echo e(Form::open(['method' => 'POST', 'route' => ['account.change-password-store']])); ?>

			<div class="card-body card-block">
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('password', 'Password', ['class' => 'optionLabel'])); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::password('currentPassword', ['class' => 'au-input au-input--full', 'placeholder' => 'Old Password'])); ?>

					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('password_confirmation', 'Re-Enter Password', ['class' => 'optionLabel'])); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::password('newPassword', ['class' => 'au-input au-input--full', 'placeholder' => 'New Password'])); ?>

					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('password_confirmation', 'Re-Enter Password', ['class' => 'optionLabel'])); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::password('confirmPassword', ['class' => 'au-input au-input--full', 'placeholder' => 'Re-Enter Password'])); ?>

					</div>
				</div>
			
		</div>
		<div class="card-footer">				
			<?php echo e(Form::submit('Submit',array('class' => 'btn btn-primary btn-lg'))); ?>

			<?php echo e(Form::submit('Reset',array('class' => 'btn btn-danger btn-lg'))); ?>

		</div>
		<?php echo e(Form::close()); ?>

			
		<!-- END DATA TABLE -->
	</div>
</div>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>