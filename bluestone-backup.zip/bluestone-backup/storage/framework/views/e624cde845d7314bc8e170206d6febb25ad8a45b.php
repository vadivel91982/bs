<?php $__env->startSection('title'); ?>
    <?php echo e("Create New Admin"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<!-- DATA TABLE -->
		<div class="table-data__tool">
			<div class="table-data__tool-left">
				<h3 class="title-5">Create New Admin</h3>
			</div>
			<div class="table-data__tool-right">
				<button onclick="javascript:location.href='<?php echo e(route('account.list')); ?>'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
		</div>
		
		
		<div class="card">
			<div class="card-header">
				<strong>Admin Form</strong>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<?php if(count($errors) > 0): ?>
					<div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<?php endif; ?>
				</div>
			</div>
			<?php echo e(Form::open(['method' => 'POST', 'route' => ['account.store'], 'files'=>'true'])); ?>

			<div class="card-body card-block">

				<div class="row form-group">
					<div class="col col-md-3">
					<?php echo e(Form::label('name', 'Name'), ['class' => 'optionLabel']); ?>

					</div>
					<div class="col-12 col-md-9">
					<?php echo e(Form::text('name', Input::old('name'), ['class' => 'au-input au-input--full', 'placeholder' => 'Name'])); ?>

						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('email', 'Email Address'), ['class' => 'optionLabel']); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::text('email', Input::old('email'), ['class' => 'au-input au-input--full', 'placeholder' => 'Email'])); ?>						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('phone', 'Phone'), ['class' => 'optionLabel']); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::text('phone', Input::old('phone'), ['class' => 'au-input au-input--full', 'placeholder' => 'Phone'])); ?>

					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('password', 'Password', ['class' => 'optionLabel'])); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::password('password', ['class' => 'au-input au-input--full', 'placeholder' => 'Password'])); ?>

					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('password_confirmation', 'Re-Enter Password', ['class' => 'optionLabel'])); ?>  
					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::password('password_confirmation', ['class' => 'au-input au-input--full', 'placeholder' => 'Re-Enter Password'])); ?>

					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('status', 'Status', ['class' => 'optionLabel'])); ?>

					</div>
					<div class="col-12 col-md-9">
						<!-- <select name="select" id="select" class="form-control">
							<option value="0">Please select</option>
							<option value="1">Active</option>
							<option value="2">Inactive</option>
						</select> -->
						<?php $arr = ['' => 'Please select', '1' => 'Active', '2'=> 'Inactive']; ?>
						<select class="form-control" id='select' class='form-control' name="status">
							<?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($item); ?>"> <?php echo e(strtoupper($item)); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<!-- <label for="file-input" class=" form-control-label">Upload Photo</label> -->
						<?php echo e(Form::label('Upload Photo', 'Upload Photo', ['class' => 'form-control-label'])); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::file('image', ['id' => 'file-input', 'class' => 'form-control-file'])); ?>

						<!-- <input type="file" id="file-input" name="file-input" class="form-control-file"> -->
					</div>
				</div>
				<?php echo e(Form::hidden('role_id', '2')); ?>

				<!-- <div class="row form-group">
					<div class="col col-md-3">
						<?php echo e(Form::label('photo', 'Upload Photo', ['class' => 'optionLabel'])); ?>

					</div>
					<div class="col-12 col-md-9">
						<?php echo e(Form::file('image',  ['class' => 'form-control-file', 'id' => 'file-input'])); ?>						
					</div>
				</div> -->
			</div>
			<div class="card-footer">				
				<?php echo e(Form::submit('Submit',array('class' => 'btn btn-primary btn-lg'))); ?>

				<?php echo e(Form::submit('Reset',array('class' => 'btn btn-danger btn-lg'))); ?>

			</div>
			<?php echo e(Form::close()); ?>

		</div>
			
		<!-- END DATA TABLE -->
	</div>
</div>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>