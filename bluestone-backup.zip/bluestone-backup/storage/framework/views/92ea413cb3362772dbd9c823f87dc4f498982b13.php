<!doctype html>
<html>
    <head>
        <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body class="animsition">
        <div class="page-wrapper">
            <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            
                <!-- MAIN CONTENT-->
                <?php if(Illuminate\Support\Facades\Auth::check()): ?>
                <div class="main-content">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">

                            <?php echo $__env->make('includes.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php echo $__env->yieldContent('content'); ?>                            
                            <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            
                        </div>
                    </div>
                </div>

            </div> <!-- page-container -->
            <?php else: ?>         
            <?php echo $__env->yieldContent('content'); ?>  
            <?php endif; ?>

           
        </div>
        <?php echo $__env->make('includes.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>