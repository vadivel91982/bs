<?php $__env->startSection('title'); ?>
    <?php echo e("Admin List"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <!-- DATA TABLE -->
        
        <div class="table-data__tool">
            <div class="table-data__tool-left">
                <h3 class="title-5">Create New Check In</h3>
            </div>
            <div class="table-data__tool-right">
				<button onclick="javascript:location.href='<?php echo e(route('visit.list')); ?>'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
        </div>
        <!-- END DATA TABLE -->
        <div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<?php if(count($errors) > 0): ?>
					<div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<?php endif; ?>
				</div>
		</div>
        <?php echo e(Form::open(['method' => 'GET', 'route' => ['visit.create'], 'files'=>'true'])); ?>								
        <div class="card">
            <div class="card-body card-block GRC">

                    <hr class="blue-hr">

                    <div class="row form-group">
                        <div class="col col-md-12">
                            <img src="images/in-logo.jpg" alt=""/>
                            <br>
                            <br>
                        </div>
                    </div>
                    <?php $__currentLoopData = $rooms->chunk(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row form-group">
                        <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col col-md-2">
                            <label class="checkbox">
                                <?php echo e(Form::checkbox('room[]', $item->room_no, false, ['id'=>'inline-checkbox', 'class' => $item->status ? 'room available' : 'room', $item->status ? '' : 'disabled'])); ?> 
                                <span class="text"><?php echo e($item->room_no); ?></span>
                                <span class="check"></span>
                            </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <hr class="blue-hr">
                        
                
            </div>
            <div class="card-footer">
               <!-- <button type="submit" class="btn btn-primary btn-lg fright">
                    <i class="fa fa-forward"></i> Next
                </button> -->
                <?php echo e(Form::submit('Next',array('class' => 'btn btn-primary btn-lg fright'))); ?>

            </div>
        </div>
        <?php echo e(Form::close()); ?>




    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>