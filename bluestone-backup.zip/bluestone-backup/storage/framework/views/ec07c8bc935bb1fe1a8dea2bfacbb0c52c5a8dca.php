<?php $__env->startSection('title'); ?>
    <?php echo e("Dashboard"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="overview-wrap">
            <h2 class="title-1">overview</h2>
            <button class="au-btn au-btn-icon au-btn--blue">
                <i class="zmdi zmdi-plus"></i>add admin</button>
        </div>
    </div>
</div>
<div class="row m-t-25">
    <div class="col-sm-4 col-lg-4">
        <div class="overview-item overview-item--c1">
            <div class="overview__inner">
                <div class="overview-box clearfix">
                    <div class="icon">
                        <i class="zmdi zmdi-account-o"></i>
                    </div>
                    <div class="text">
                        <h2><?php echo e($admin); ?></h2>
                        <span>total admin</span>
                    </div>
                </div>
                <div class="overview-chart">
                    <!-- <canvas id="widgetChart2"></canvas> -->
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-4 col-lg-4">
        <div class="overview-item overview-item--c2">
            <div class="overview__inner">
                <div class="overview-box clearfix">
                    <div class="icon">
                        <i class="zmdi zmdi-account-o"></i>
                    </div>
                    <div class="text">
                        <h2><?php echo e($customer); ?></h2>
                        <span>total customer</span>
                    </div>
                </div>
                <div class="overview-chart">
                    <!-- <canvas id="widgetChart1"></canvas> -->
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-4 col-lg-4">
        <div class="overview-item overview-item--c3">
            <div class="overview__inner">
                <div class="overview-box clearfix">
                    <div class="icon">
                        <i class="zmdi zmdi-shopping-cart"></i>
                    </div>
                    <div class="text">
                        <h2><?php echo e($totalcheckout); ?></h2>
                        <span>total check-out</span>
                    </div>
                </div>
                <div class="overview-chart">
                    <!-- <canvas id="widgetChart3"></canvas> -->
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="col-sm-6 col-lg-3">
        <div class="overview-item overview-item--c4">
            <div class="overview__inner">
                <div class="overview-box clearfix">
                    <div class="icon">
                        <i class="zmdi zmdi-money"></i>
                    </div>
                    <div class="text">
                        <h2>$1,060,386</h2>
                        <span>total earnings</span>
                    </div>
                </div>
                <div class="overview-chart">
                    <canvas id="widgetChart4"></canvas>
                </div>
            </div>
        </div>
    </div> -->
</div>


<div class="row">
    <div class="col-lg-6">
        <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
            <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
                <div class="bg-overlay bg-overlay--blue"></div>
                <h3>
                    <i class="zmdi zmdi-account-calendar"></i><?php echo e(date('d M, Y')); ?> - Check In</h3>
            </div>
            <div class="au-inbox-wrap js-inbox-wrap">
                <div class="au-message js-list-load">
                    <div class="au-message__noti">
                        <p>You Have
                            <span><?php echo e(count($checkin)); ?></span>

                            CheckIn Today
                        </p>
                    </div>
                    <div class="au-message-list">
                    <?php $__currentLoopData = $checkin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="au-message__item">
                            <div class="au-message__item-inner">
                                <div class="au-message__item-text">
                                    <div>
                                        <h5 class="name"><lable>Name: </label><?php echo e($user->name); ?></h5>
                                        <p><lable><strong>Phone:</strong> </label><?php echo e($user->phone); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="au-message__footer">
                        <button onclick="javascript:location.href='<?php echo e(route('visit.list')); ?>'"  class="au-btn au-btn-load js-load-btn">load more</button>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
            <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
                <div class="bg-overlay bg-overlay--blue"></div>
                <h3>
                    <i class="zmdi zmdi-account-calendar"></i><?php echo e(date('d M, Y')); ?> - Check Out</h3>
            </div>
            <div class="au-inbox-wrap js-inbox-wrap">
                <div class="au-message js-list-load">
                    <div class="au-message__noti">
                        <p>You Have
                            <span><?php echo e(count($checkout)); ?></span>

                            CheckOut Today
                        </p>
                    </div>
                    <div class="au-message-list">
                    <?php $__currentLoopData = $checkout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="au-message__item">
                            <div class="au-message__item-inner">
                                <div class="au-message__item-text">
                                    <div>
                                        <h5 class="name"><lable>Name: </label><?php echo e($user->name); ?></h5>
                                        <p><lable><strong>Phone:</strong> </label><?php echo e($user->phone); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="au-message__footer">
                        <button onclick="javascript:location.href='<?php echo e(route('visit.list')); ?>'" class="au-btn au-btn-load js-load-btn">load more</button>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
                    
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>