<?php $__env->startSection('title'); ?>
    <?php echo e("Create New Admin"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <!-- DATA TABLE -->
        <div class="table-data__tool">
            <div class="table-data__tool-left">
                <h3 class="title-5">Create New Check In</h3>
            </div>
            <div class="table-data__tool-right">
				<button onclick="javascript:location.href='<?php echo e(route('visit.list')); ?>'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
        </div>
        <div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<?php if(count($errors) > 0): ?>
					<div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<?php endif; ?>
				</div>
		</div>
        <!-- <form action="" method="post" enctype="multipart/form-data" class="form-horizontal"> -->
        <?php echo e(Form::open(['method' => 'POST', 'route' => ['visit.store'], 'files'=>'true'])); ?>

        
        <div class="card">
            <div class="card-header">
                <strong>Check In Form</strong>
            </div>
            <div class="card-body card-block GRC">            
                    <div class="row form-group">
                        <div class="col col-md-4">
                            <img src="/images/Print-logo.jpg" alt="BlueStone">
                        </div>
                        <div class="col col-md-5"></div>
                        <div class="col col-md-3 gstin-right">
                                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                    <colgroup>
                                        <col width="30%">
                                        <col width="5%">
                                        <col width="65%">
                                    </colgroup>
                                    <tr>
                                        <td>GSTIN</td>
                                        <td>:</td>
                                        <td>34AYOPK2790F1Z8</td>
                                    </tr>
                                    <tr>
                                        <td>G.R.C No.</td>
                                        <td>:</td>
                                        <td>3659</td>
                                    </tr>
                                    <tr>
                                        <td>Room No.</td>
                                        <td>:</td>
                                        <td>
                                            <?php echo e(Form::text('room_no', $availableRooms, ['class' => 'form-control'])); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Date</td>
                                        <td>:</td>
                                        <td>
                                            <?php echo e(Form::text('arrival_date', Input::old('arrival_date'), ['size' => '16', 'readonly', 'class' => 'form-control', 'id'=>'datetimepicker'])); ?>                                            
                                        </td>                                        
                                    </tr>
                                </table>
                        </div>
                    </div>
                    <hr class="blue-hr">
                    
                    <div class="row form-group">
                        <div class="col col-md-12 text-center">
                            <h2>Guest Registration Card</h2>
                        </div>
                        <div class="col col-md-12">                        
                            <div class="profile">
                                <div class="photo">
                                    <div class="photo__helper">
                                        <div class="photo__frame photo__frame--circle">
                                        <div id="user_avatar" onClick="avatar_snapshot()" title="Click the image to take photo"></div>
                                        <div id="results">Your captured image will appear here...</div>
                                    </div>
                                    </div>
                                </div>
                            </div> 
                      
                        </div>											
                    </div>                                    
                    <div class="row form-group">
                        <div class="col col-md-4">
                            <label for="text-input" class=" form-control-label">Full Name</label>
                            <?php echo e(Form::text('name', Input::old('name'), ['class' => 'form-control', 'id' => 'text-input', 'placeholder' => 'Enter your Name', ''])); ?>

                            <?php echo e(Form::hidden('avatar', '', ['class' => 'form-control', 'id' => 'avatar-url', 'placeholder' => 'Image url', ''])); ?>

                            <?php echo e(Form::hidden('user_proof', '', ['class' => 'form-control', 'id' => 'proof-url', 'placeholder' => 'Image url', ''])); ?>

                        </div>
                            
                        <div class="col col-md-4">
                            <label for="mobile-input" class=" form-control-label">Mobile</label>
                            <?php echo e(Form::text('mobile', Input::old('mobile'), ['class' => 'form-control', 'id' => 'text-input', 'placeholder' => 'Enter your mobile no.', ''])); ?>

                        </div>
                        <div class="col col-md-4">
                            <label for="email-input" class=" form-control-label">Email</label>
                            <?php echo e(Form::text('email', Input::old('email'), ['class' => 'form-control', 'id' => 'text-input', 'placeholder' => 'Enter your Email'])); ?>

                        </div>
                    </div>                    
                    <div class="row form-group">
                        <div class="col col-md-4">
                            <div class="row form-group">
                                <div class="col col-md-12">
                                    <label for="textarea-input" class=" form-control-label">Address</label>
                                    <?php echo e(Form::textarea('address',Input::old('address'),array('id'=>'textarea-input', 'rows'=>'9', 'placeholder'=>'Enter your Permanent Address', 'class'=>'form-control check-textarea', ''))); ?>

                                    </div>
                            </div>                            
                        </div>
                        <div class="col col-md-8">
                            <div class="row form-group">
                                <div class="col col-md-6">
                                    <label for="company-input" class=" form-control-label">Company</label>
                                    <?php echo e(Form::text('company', Input::old('company'), ['class' => 'form-control', 'id' => 'company-input', 'placeholder' => 'Enter Company Name'])); ?>

                                </div>
                                <div class="col col-md-6">
                                    <label for="visit-input" class=" form-control-label">Purpose of Visit</label>
                                   <?php echo e(Form::text('purpose', Input::old('purpose'), ['class' => 'form-control', 'id' => 'visit-input', 'placeholder' => 'Enter Purpose of Visit', ''])); ?>

                                </div>                                
                            </div>
                            <div class="row form-group">
                                <div class="col col-md-6">
                                    <label for="vehicle-input" class=" form-control-label">Vehicle No.</label>
                                    <?php echo e(Form::text('vehicle', Input::old('vehicle'), ['class' => 'form-control', 'id' => 'vehicle-input', 'placeholder' => 'Enter Vehicle No.'])); ?>

                                </div>
                                <div class="col col-md-6">
                                    <label for="person-input" class=" form-control-label">No. of Person</label>
                                    <div class="row form-group">
                                        <div class="col col-md-6">                                            
                                            <?php $adult = ['' => 'Adult', '1' => '1', '2'=> '2', '3'=> '3', '4'=> '4', '5'=> '5', '6'=> '6', '7'=> '7', '8'=> '8', '9'=> '9', '10'=> '10']; ?>
                                            <select class="form-control" id="person-input" name="adult">
                                                <?php $__currentLoopData = $adult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item); ?>"> <?php echo e(strtoupper($item)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col col-md-6">
                                            <?php $child = ['' => 'Child', '1' => '1', '2'=> '2', '3'=> '3', '4'=> '4', '5'=> '5', '6'=> '6', '7'=> '7', '8'=> '8', '9'=> '9', '10'=> '10']; ?>
                                            <select class="form-control" id="person-input" name="child">
                                                <?php $__currentLoopData = $child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $childItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($childItem); ?>"> <?php echo e(strtoupper($childItem)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                            <div class="row form-group">                                
                                <div class="col col-md-6">
                                    <label for="person-input" class=" form-control-label">ID Proof</label>
                                    <div class="row form-group">
                                        <div class="col col-md-4">
                                             <?php $idProof = ['aadhar' => 'Aadhar', 'driving' => 'Driving License', 'others'=> 'Others']; ?>
                                            <select class="form-control" id="person-input" name="proof_type">
                                                <?php $__currentLoopData = $idProof; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item); ?>"> <?php echo e(strtoupper($item)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col col-md-8">
                                            <?php echo e(Form::text('proof', Input::old('proof'), ['class' => 'form-control', 'id' => 'id-input', 'placeholder' => 'Enter ID Proof', ''])); ?>

                                        </div>                                        
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                        <div class="col col-md-12">
                            <div class="profile">
                                <div class="photo">
                                    <div class="photo__helper">
                                        <div class="photo__frame photo__frame--circle">
                                        <div id="user_proof" onClick="proof_snapshot()" title="Click the image to take photo"></div>
                                        <div id="proof_results">ID proof captured image will appear here...</div>  
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>                    
                    <hr class="blue-hr">
                    <div class="row form-group">
                        <div class="col col-md-12 text-center">
                            <h2>Additional Information for Foreigners Only</h2>
                        </div>
                        <div class="col col-md-12">                        
                            <div class="profile3">
                                <div class="photo">
                                    <div class="photo__helper">
                                        <div class="photo__frame"></div>
                                    </div>
                                </div>
                            </div>                        
                        </div>											
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-4">
                            <label for="nationality-input" class=" form-control-label">Nationality</label>
                            <?php echo e(Form::text('frgn_nationality', Input::old('frgn_nationality'), ['class' => 'form-control', 'id' => 'id-input', 'placeholder' => 'Enter Nationality'])); ?>

                        </div>
                        <div class="col col-md-4">
                            <label for="birth-input" class=" form-control-label">Date of Birth</label>
                            <div class="input-group">
                                <?php echo e(Form::text('frgn_dob', Input::old('frgn_dob'), ['class' => 'form-control', 'id' => 'birth-input', 'placeholder' => 'MM/DD/YY'])); ?>

                            </div>
                        </div>
                        <div class="col col-md-4">
                            <label for="passport-input" class=" form-control-label">Passport No.</label>
                            <?php echo e(Form::text('frgn_passport', Input::old('frgn_passport'), ['class' => 'form-control', 'id' => 'passport-input', 'placeholder' => 'Enter Passport No.'])); ?>

                        </div>                        
                    </div>                    
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="issue-input" class=" form-control-label">Date & Place of Issue</label>
                            <?php echo e(Form::text('frgn_date_place', Input::old('frgn_date_place'), ['class' => 'form-control', 'id' => 'issue-input', 'placeholder' => 'Enter Date & Place of Issue'])); ?>

                        </div>
                        <div class="col col-md-3">
                            <label for="validity-input" class=" form-control-label">Validity</label>
                           <?php echo e(Form::text('frgn_validity', Input::old('frgn_validity'), ['class' => 'form-control', 'id' => 'validity-input', 'placeholder' => 'Enter Validity'])); ?>

                        </div>
                        <div class="col col-md-3">
                            <label for="local-input" class=" form-control-label">Local Address or Phone</label>
                            <?php echo e(Form::text('frgn_local_address', Input::old('frgn_local_address'), ['class' => 'form-control', 'id' => 'local-input', 'placeholder' => 'Enter Local Contact Address or Phone'])); ?>

                        </div>
                        <div class="col col-md-3">
                            <label class=" form-control-label">Employed in India?</label><br>
                            <div class="form-check-inline form-check">
                                <label for="inline-radio1" class="form-check-label ">
                                    <?php echo e(Form::radio('frgn_employed', 1, false, ['id' => "inline-radio1", 'class' => 'form-check-input'])); ?> Yes
                                </label>&nbsp;&nbsp;
                                <label for="inline-radio2" class="form-check-label ">
                                    <?php echo e(Form::radio('frgn_employed', 1, true, ['id' => "inline-radio2", 'class' => 'form-check-input'])); ?> No
                                </label>
                            </div>
                        </div>                        
                    </div>                    
                    <hr class="blue-hr">
                    <div class="row form-group guest-inst">
                        <div class="col col-md-8">
                            <ul>
                                <li>The Management does not take responsiblity for the valuables left in the room.</li>
                                <li><b>Check-in 12 noon / check-out 11 Am</b></li>
                                <li>I have gone through the terms and conditions governing my stay in hotel and I agree to abide by them.</li>
                            </ul>
                        </div>
                        <div class="col col-md-4 text-right">
                            <h4><span>Guest Signature</span></h4>
                        </div>
                    </div>
                    <hr class="blue-hr">
                    <div class="row form-group">
                        <div class="col col-md-12 text-center">
                            <h2>Office Use only</h2>
                        </div>
                    </div>
                    <div class="row form-group guest-inst">
                        <div class="col col-md-8">
                            <div class="row form-group">
                                <div class="col col-md-6">
                                    <label for="occupancy-input" class=" form-control-label">Occupancy</label><br>
                                    <div class="form-check-inline form-check">
                                        <label for="inline-checkbox1" class="form-check-label ">
                                            <?php echo e(Form::checkbox('ocpy_single', 1, true, ['id'=>'inline-checkbox1', 'class' => 'form-check-input'])); ?> Single
                                        </label>&nbsp;&nbsp;
                                        <label for="inline-checkbox2" class="form-check-label ">
                                            <?php echo e(Form::checkbox('ocpy_double', 1, null, ['id'=>'inline-checkbox2', 'class' => 'form-check-input'])); ?> Double
                                        </label>
                                    </div>
                                </div>
                                <div class="col col-md-6">
                                    <label for="occupancy-input" class=" form-control-label">Type of Room</label><br>
                                    <div class="form-check-inline form-check">
                                        <label for="inline-checkbox1" class="form-check-label ">
                                            <?php echo e(Form::checkbox('room_type_ac', 1, true, ['id'=>'inline-checkbox1', 'class' => 'form-check-input'])); ?> A/C
                                        </label>&nbsp;&nbsp;
                                        
                                        <label for="inline-checkbox2" class="form-check-label ">
                                            <?php echo e(Form::checkbox('room_type_nonac', 1, false, ['id'=>'inline-checkbox2', 'class' => 'form-check-input'])); ?> Non A/C
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">                                
                                <div class="col col-md-6">
                                    <label for="settlement-input" class=" form-control-label">Advance</label>
                                    <?php echo e(Form::text('advance', Input::old('advance'), ['class' => 'form-control', 'id' => 'settlement-input', 'placeholder' => 'Direct by Cash'])); ?>

                                </div>
                                <div class="col col-md-6">
                                    <label for="voucher-input" class=" form-control-label">Receipt No</label>
                                    <?php echo e(Form::text('receipt_no', Input::old('receipt_no'), ['class' => 'form-control', 'id' => 'settlement-input', 'placeholder' => 'Enter the receipt no.'])); ?>

                                </div>
                            </div>
                        </div> 
                        <div class="col col-md-4 text-right">
                            <h4><span>Front Office Assistant</span></h4>
                        </div>
                    </div>                
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary btn-lg fright">
                    <i class="fa fa-floppy-o"></i> Submit
                </button>
                <button type="reset" class="btn btn-danger btn-lg fright">
                    <i class="fa fa-ban"></i> Reset
                </button>
            </div>
        </div>
    </form>
        <!-- END DATA TABLE -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
        $(function(){
            $("#datetimepicker").datetimepicker({
                startDate: new Date(),
                format: "mm/dd/yyyy HH:ii P",
                showMeridian: true,
                autoclose: true,
                todayBtn: true
            });
        });    
        
        
		Webcam.set({
			width: 250,
			height: 250,
			image_format: 'jpeg',
			jpeg_quality: 90,
			constraints: {
				width: { exact: 250 },
				height: { exact: 250 }
			}
        });
        
        Webcam.attach( '#user_avatar' );

		function avatar_snapshot() {
			// take snapshot and get image data
			Webcam.snap( function(data_uri) {
				// display results in page
			document.getElementById('results').innerHTML = 
					'<p>Preview Image</p>' + 
                    '<img src="'+data_uri+'"/>';
            var raw_image_data = data_uri.replace(/^data\:image\/\w+\;base64\,/, '');
                $("#avatar-url").val(raw_image_data);
            } );
        }

        Webcam.attach( '#user_proof' );
        function proof_snapshot() {
			// take snapshot and get image data
			Webcam.snap( function(data_uri) {
				// display results in page
			document.getElementById('proof_results').innerHTML = 
					'<p>Preview ID Proof</p>' + 
                    '<img src="'+data_uri+'"/>';
            var raw_image_data = data_uri.replace(/^data\:image\/\w+\;base64\,/, '');
                $("#proof-url").val(raw_image_data);
			} );
		}
    </script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>