<?php $__env->startSection('title'); ?>
    <?php echo e("User Login"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content--bge5">
	<div class="container">
			<div class="login-wrap">
				<div class="login-content">
					<div class="login-logo">
						<a href="#">
							<img src="/images/bluelogo.png" alt="BlueStone">
						</a>
					</div>
					<div class="row">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<?php if(count($errors) > 0): ?>
								<div class="alert alert-danger">
									<button type="button" class="close" data-dismiss="alert">×</button>
									<ul>
										<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><?php echo e($error); ?></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</div>
								<?php endif; ?>
							</div>
						</div>
					<div class="login-form">
						<?php echo e(Form::open(['method' => 'POST', 'route' => ['user.store']])); ?>


							<div class="form-group">
								<?php echo e(Form::label('email', 'Email Address'), ['class' => 'optionLabel']); ?>

								<?php echo e(Form::text('email', Input::old('email'), ['class' => 'au-input au-input--full', 'placeholder' => 'Email'])); ?>

							</div>		
							<div class="form-group">
								<?php echo e(Form::label('password', 'Password', ['class' => 'optionLabel'])); ?>

								<?php echo e(Form::password('password', ['class' => 'au-input au-input--full', 'placeholder' => 'Password'])); ?>

                            </div>					
							<div class="login-checkbox">
								<label>
									<input type="checkbox" name="remember">Remember Me
								</label>
								<label>
								<?php echo e(Html::link('password/reset', 'Forgot Password')); ?>

								</label>
							</div>
							<?php echo e(Form::submit('Sign In',array('class' => 'au-btn au-btn--block au-btn--orange m-b-20'))); ?>

						<?php echo e(Form::close()); ?>

						<!-- <div class="register-link">
							<p>
								Don't you have account?
								<a href="#">Sign Up Here</a>
							</p>
						</div> -->
					</div>
				</div>
			</div>
    </div>
</div>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>