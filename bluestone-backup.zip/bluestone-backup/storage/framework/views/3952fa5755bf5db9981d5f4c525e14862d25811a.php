<?php if(Illuminate\Support\Facades\Auth::check()): ?>
<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">
        <a href="/">
            <img src="/images/bluelogo.png" alt="BlueStone" />
        </a>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li class="active has-sub">
                    <a class="js-arrow" href="/"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
                </li>
                <?php if(Auth::user()->role_id == 1): ?>
                <li <?php echo e((Route::is('account.list') ? 'class=active' : '')); ?>>
                <a href="<?php echo e(route('account.list')); ?>"><i class="fa fa-user"></i>Admin</a>
                </li>
                <?php endif; ?>
                <li <?php echo e((Route::is('visit.list') ? 'class=active' : '')); ?> || <?php echo e((Route::is('visit.create') ? 'class=active' : '')); ?>>
                    <a href="<?php echo e(route('visit.list')); ?>"><i class="fa fa-home"></i>Check In</a>
                </li>

                <li>
                    <a href="#"><i class="far fa-check-square"></i>Check Out</a>
                </li>
                <li <?php echo e((Route::is('account.profile') ? 'class=active' : '')); ?>>
                    <a href="<?php echo e(route('account.profile')); ?>"><i class="fa fa-gear"></i>Profile</a>
                </li>
                <li <?php echo e((Route::is('user.logout') ? 'class=active' : '')); ?>>
                    <a href="<?php echo e(route('user.logout')); ?>"><i class="fa fa-lock"></i>Logout</a>
                </li>                
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->

<div class="page-container">
    <!-- HEADER DESKTOP-->
    <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                <!-- <input class="au-input au-input--xl" type="text" name="search" placeholder="Search for datas &amp; reports..." />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button> -->
                            </form>
                            <div class="header-button">
                                
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="/images/customer/<?php echo e(Auth::user()->avatar); ?>" alt="<?php echo e(Auth::user()->name); ?>" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php echo e(Auth::user()->name); ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="/images/avatar.jpg" alt="Super Admin" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo e(Auth::user()->name); ?></a>
                                                    </h5>
                                                    <span class="email"><?php echo e(Auth::user()->email); ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="<?php echo e(route('account.change-password')); ?>"><i class="zmdi zmdi-account"></i>Chage Password</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="<?php echo e(route('account.profile')); ?>"><i class="zmdi zmdi-account"></i>Profile</a>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="<?php echo e(route('user.logout')); ?>"
                                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                                    <i class="zmdi zmdi-power"></i>Logout
                                                </a>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->



<?php endif; ?>