<?php
use App\Http\Middleware\CheckRole;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home');


  // Authentication Routes...
  //Route::get('login', 'Auth\LoginController@showLoginForm')->name('login');
  //Route::post('login', 'Auth\LoginController@login');
  Route::post('logout', 'Auth\LoginController@logout')->name('logout');

  // Registration Routes...
  Route::get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');
  Route::post('register', 'Auth\RegisterController@register');

  // Password Reset Routes...
  Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
  Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
  Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
  Route::post('password/reset', 'Auth\ResetPasswordController@reset');

    //Route::group(['middleware' => ['user', 'revalidate']], function () {
    Route::prefix('user')->group(function () {
        Route::get('login', ['as' => 'user.login', 'uses' => 'Auth\LoginController@postLogin']);
        Route::post('store', ['as' => 'user.store', 'uses' => 'Auth\LoginController@store']);
        Route::get('logout', ['as' => 'user.logout', 'uses' => 'Auth\LoginController@logout']);
    });
//});

Auth::routes();

Route::group(['middleware' => ['webAuth']], function () {  
    Route::prefix('account')->group(function () {
        Route::get('create', ['as' => 'account.create', 'uses' => 'User\UserController@create'])->middleware(CheckRole::class);
        Route::post('store', ['as' => 'account.store', 'uses' => 'User\UserController@store'])->middleware(CheckRole::class);
        Route::get('list','User\UserController@getIndex')->name('account.list')->middleware(CheckRole::class);
        Route::get('anyData','User\UserController@anyData')->name('datatables.data');
        Route::get('edit/{id}',['as' => 'account.edit', 'uses' => 'User\UserController@edit']);
        Route::patch('update/{id}', ['as' => 'account.update', 'uses' => 'User\UserController@update']);
        Route::get('destroy/{id}', ['as' => 'account.delte', 'uses' => 'User\UserController@destroy']);
        Route::get('change-password', ['as' => 'account.change-password', 'uses' => 'User\UserController@changePassword']);
        Route::post('change-password-store', ['as' => 'account.change-password-store', 'uses' => 'User\UserController@changePasswordStore']);
        Route::get('profile/', ['as' => 'account.profile', 'uses' => 'User\UserController@profile']);
        //Visit
        Route::get('rooms-list','Visit\VisitController@listRooms')->name('rooms.list');
        //Route::post('rooms-get', ['as' => 'rooms.get', 'uses' => 'Visit\VisitController@getRooms']);
        Route::get('visit-list','Visit\VisitController@getIndex')->name('visit.list');
        Route::get('visitData','Visit\VisitController@visitData')->name('visitdatatables.data');
        Route::get('visit-create', ['as' => 'visit.create', 'uses' => 'Visit\VisitController@create']);
        Route::post('VisitStore', ['as' => 'visit.store', 'uses' => 'Visit\VisitController@store']);
        Route::get('visit-edit/{id}', ['as' => 'visit.edit', 'uses' => 'Visit\VisitController@edit']);
        Route::patch('visit-update/{id}', ['as' => 'visit.update', 'uses' => 'Visit\VisitController@update']);
        //Checkout
        Route::get('checkout/{id}', ['as' => 'checkout', 'uses' => 'Visit\VisitController@showForm']);
        Route::post('visitBilling/{id}', ['as' => 'visit.billing', 'uses' => 'Visit\VisitController@createBilling']);
    });
});

Route::get('/home', 'HomeController@index')->name('home');
