-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 06, 2018 at 11:51 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bsh_backoffice`
--

-- --------------------------------------------------------

--
-- Table structure for table `bsh_billing`
--

DROP TABLE IF EXISTS `bsh_billing`;
CREATE TABLE IF NOT EXISTS `bsh_billing` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `visit_id` int(11) NOT NULL,
  `service` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gst` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cgst` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sgst` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bsh_migrations`
--

DROP TABLE IF EXISTS `bsh_migrations`;
CREATE TABLE IF NOT EXISTS `bsh_migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bsh_migrations`
--

INSERT INTO `bsh_migrations` (`id`, `migration`, `batch`) VALUES
(3, '2014_10_12_000000_create_users_table', 1),
(4, '2014_10_12_100000_create_password_resets_table', 1),
(5, '2018_06_22_070729_create_roles_table', 2),
(6, '2018_06_25_104717_create_billing_table', 3),
(7, '2018_06_25_124232_create_visit_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `bsh_password_resets`
--

DROP TABLE IF EXISTS `bsh_password_resets`;
CREATE TABLE IF NOT EXISTS `bsh_password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bsh_roles`
--

DROP TABLE IF EXISTS `bsh_roles`;
CREATE TABLE IF NOT EXISTS `bsh_roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bsh_roles`
--

INSERT INTO `bsh_roles` (`id`, `role_name`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 1, '2018-06-22 01:59:23', '2018-06-22 01:59:23'),
(2, 'Admin', 2, '2018-06-22 01:59:23', '2018-06-22 01:59:23'),
(3, 'Customer', 3, '2018-06-22 01:59:23', '2018-06-22 01:59:23');

-- --------------------------------------------------------

--
-- Table structure for table `bsh_rooms`
--

DROP TABLE IF EXISTS `bsh_rooms`;
CREATE TABLE IF NOT EXISTS `bsh_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_no` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bsh_rooms`
--

INSERT INTO `bsh_rooms` (`id`, `room_no`, `status`, `created_at`, `updated_at`) VALUES
(1, 101, 0, '2018-07-18 18:30:00', '2018-07-18 18:30:00'),
(2, 102, 1, '2018-07-18 18:30:00', '2018-07-18 18:30:00'),
(3, 103, 1, '2018-07-18 18:30:00', '2018-07-18 18:30:00'),
(4, 104, 0, '2018-07-18 18:30:00', '2018-07-18 18:30:00'),
(5, 105, 1, '2018-07-18 18:30:00', '2018-07-18 18:30:00'),
(6, 106, 1, '2018-07-18 18:30:00', '2018-07-18 18:30:00'),
(7, 107, 1, '2018-07-18 18:30:00', '2018-07-18 18:30:00'),
(8, 108, 0, '2018-07-18 18:30:00', '2018-07-18 18:30:00'),
(9, 109, 1, '2018-07-18 18:30:00', '2018-07-18 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `bsh_users`
--

DROP TABLE IF EXISTS `bsh_users`;
CREATE TABLE IF NOT EXISTS `bsh_users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehicle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `proof_type` enum('aadhar','driving') COLLATE utf8mb4_unicode_ci NOT NULL,
  `proof` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bsh_users`
--

INSERT INTO `bsh_users` (`id`, `role_id`, `name`, `email`, `password`, `phone`, `avatar`, `status`, `address`, `company`, `vehicle`, `proof_type`, `proof`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 1, 'sravan 1234', 'sravankumar.p@pluselve.com', '$2y$10$AR7Xjltc9RO7BjbETiN44OKFBz6Bv8L3nvQ2JOYv270psniSdGQt2', '9943179671', 'avatar.png', 1, '', '', '', 'aadhar', '', '1GgR3eovGwwhR3TXJsO9AG3LapOvCjiIhebYmfBKo7dGkJNWOaJESc7SYAvi', '2018-06-17 13:00:00', '2018-07-03 04:50:11', NULL),
(3, 2, 'sravan 456sdfsdfsdfs', 'sravankumarghghghfghf.p@pluselve.com', '$2y$10$b6MwTNGgzeYdkTUVeVyN9ua2YmC7KqJYF/Z8o34TJoYCIi.L5rDRC', '9943179671', '1530613525-avatar.jpg', 1, '', '', '', 'aadhar', '', 'TAU4YNvvIzPc2jshnzBIdAL8UjAzrJwAm1L7gw5Or0TOvLDq0ofAHpVy1XjR', '2018-06-17 13:00:00', '2018-07-06 01:27:06', NULL),
(4, 3, 'sravan1', 'customer@gmail.com', '$2y$10$b6MwTNGgzeYdkTUVeVyN9ua2YmC7KqJYF/Z8o34TJoYCIi.L5rDRC', '9943179671', '', 1, '', '', '', 'aadhar', '', 'TAU4YNvvIzPc2jshnzBIdAL8UjAzrJwAm1L7gw5Or0TOvLDq0ofAHpVy1XjR', '2018-06-17 13:00:00', '2018-06-17 13:00:00', NULL),
(5, 3, 'sravan1', 'customer2@gmail.com', '$2y$10$b6MwTNGgzeYdkTUVeVyN9ua2YmC7KqJYF/Z8o34TJoYCIi.L5rDRC', '9943179671', '', 1, '', '', '', 'aadhar', '', 'TAU4YNvvIzPc2jshnzBIdAL8UjAzrJwAm1L7gw5Or0TOvLDq0ofAHpVy1XjR', '2018-06-17 13:00:00', '2018-07-06 01:26:17', '2018-07-06 01:26:17'),
(6, 2, 'ashok', 'ashok@gmail.com', '$2y$10$DD0A.7R9gZdLR3.3J5GJAeu.jzaIs/dIXy/Q0tWSL8m0to4NNciPu', '995241452', '1530618645-avatar.jpg', 0, '', '', '', 'aadhar', '', NULL, '2018-07-03 06:20:45', '2018-07-06 00:59:34', '2018-07-06 00:59:34'),
(7, 3, 'fsafsfsadf', 'sravankumar.p252@pluselve.com', '', '65465465456', '', 1, 'fsdfsdf', 'fsdfsdfsdfs', '65465456', 'aadhar', '65465456', NULL, '2018-07-13 02:08:02', '2018-07-13 02:08:02', NULL),
(8, 3, '546565', 'sravankumar.p111@pluselve.com', '', '65465465456', '5b485866ad8fd.jpeg', 1, 'fsdafsdfsd', 'fsdfsdfsdfs', '65465456', '', '65465456', NULL, '2018-07-13 02:14:38', '2018-07-13 02:14:38', NULL),
(9, 3, 'fsfsfsd', 'sravankumar.p11fdfd1@pluselve.com', '', '65465465456', 'avatar-5b4883e0af5fe.jpeg', 1, 'fsdfs', 'fsdfsdf', '65465456', 'aadhar', '65465456', NULL, '2018-07-13 05:20:08', '2018-07-13 05:20:08', NULL),
(10, 3, 'fsfsfsd', 'sravankumar.edrdr@pluselve.com', '', '65465465456', 'avatar-5b4884ef48f18.jpeg', 1, 'fsdfs', 'fsdfsdf', '65465456', 'aadhar', '65465456', NULL, '2018-07-13 05:24:39', '2018-07-13 05:24:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bsh_visit`
--

DROP TABLE IF EXISTS `bsh_visit`;
CREATE TABLE IF NOT EXISTS `bsh_visit` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `room_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehicle` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `proof_type` enum('aadhaar','driving','others') COLLATE utf8mb4_unicode_ci NOT NULL,
  `proof` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adult` int(11) NOT NULL,
  `child` int(11) NOT NULL,
  `arrival_date` datetime NOT NULL,
  `departure_date` datetime NOT NULL,
  `frgn_nationality` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frgn_dob` date NOT NULL,
  `frgn_passport` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frgn_date_place` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frgn_validity` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frgn_local_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frgn_employed` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ocpy_single` int(11) NOT NULL,
  `ocpy_double` int(11) NOT NULL,
  `room_type_ac` int(11) NOT NULL,
  `room_type_nonac` int(11) NOT NULL,
  `advance` int(11) NOT NULL,
  `receipt_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `visit_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bsh_visit`
--

INSERT INTO `bsh_visit` (`id`, `user_id`, `admin_id`, `room_no`, `name`, `email`, `phone`, `status`, `avatar`, `address`, `company`, `vehicle`, `proof_type`, `proof`, `purpose`, `adult`, `child`, `arrival_date`, `departure_date`, `frgn_nationality`, `frgn_dob`, `frgn_passport`, `frgn_date_place`, `frgn_validity`, `frgn_local_address`, `frgn_employed`, `ocpy_single`, `ocpy_double`, `room_type_ac`, `room_type_nonac`, `advance`, `receipt_no`, `created_at`, `updated_at`) VALUES
(1, 2, 0, '123', 'Ashok', 'ashok@gmail.com', 54655645, 1, '', 'my address', 'Pluselve', '65465', 'aadhaar', 'proof', 'official', 1, 1, '2018-06-27 00:00:00', '2018-06-28 00:00:00', 'rw', '2018-06-27', 'fsfds', 'sdfsdfs', 'dfsfsd', 'sdfsdf', '1', 1, 1, 1, 1, 100, '100', '2018-06-26 18:30:00', '2018-06-26 18:30:00'),
(2, 2, 0, '123', 'Ram', 'ram@gmail.com', 54655645, 1, '', 'my address', 'Pluselve', '65465', 'aadhaar', 'proof', 'official', 1, 1, '2018-06-27 11:59:00', '2018-06-28 00:00:00', 'rw', '2018-06-27', 'fsfds', 'sdfsdfs', 'dfsfsd', 'sdfsdf', '1', 1, 1, 1, 1, 100, '100', '2018-06-26 18:30:00', '2018-06-26 18:30:00'),
(3, 2, 0, '123', 'Chitti', 'chitti@gmail.com', 54655645, 2, '', 'my address', 'Pluselve', '65465', 'aadhaar', 'proof', 'official', 1, 1, '2018-06-27 11:59:00', '2018-06-27 00:00:00', 'rw', '2018-06-27', 'fsfds', 'sdfsdfs', 'dfsfsd', 'sdfsdf', '1', 1, 1, 1, 1, 100, '100', '2018-06-26 18:30:00', '2018-06-26 18:30:00'),
(4, 2, 0, '123', 'Kiran', 'Kiran@gmail.com', 54655645, 2, '', 'my address', 'Pluselve', '65465', 'aadhaar', 'proof', 'official', 1, 1, '2018-06-27 11:59:00', '2018-06-27 00:00:00', 'rw', '2018-06-27', 'fsfds', 'sdfsdfs', 'dfsfsd', 'sdfsdf', '1', 1, 1, 1, 1, 100, '100', '2018-06-26 18:30:00', '2018-06-26 18:30:00'),
(5, 2, 0, '123', 'Kiran', 'karan@gmail.com', 54655645, 2, '', 'my address', 'Pluselve', '65465', 'aadhaar', 'proof', 'official', 1, 1, '2018-06-27 11:59:00', '2018-06-27 00:00:00', 'rw', '2018-06-27', 'fsfds', 'sdfsdfs', 'dfsfsd', 'sdfsdf', '1', 1, 1, 1, 1, 100, '100', '2018-06-26 18:30:00', '2018-06-26 18:30:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
