@extends('layouts.master')
@section('title')
    {{"Admin List"}}
@stop

@section('content')
<div class="row">
    <div class="col-md-12">
        <!-- DATA TABLE -->
        
        <div class="table-data__tool">
            <div class="table-data__tool-left">
                <h3 class="title-5">Create New Check In</h3>
            </div>
            <div class="table-data__tool-right">
				<button onclick="javascript:location.href='{{route('visit.list')}}'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
        </div>
        <!-- END DATA TABLE -->
        <div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					@if (count($errors) > 0)
					<div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<ul>
							@foreach ($errors->all() as $error)
							<li>{{ $error }}</li>
							@endforeach
						</ul>
					</div>
					@endif
				</div>
		</div>
        {{ Form::open(['method' => 'GET', 'route' => ['visit.create'], 'files'=>'true'])}}								
        <div class="card">
            <div class="card-body card-block GRC">

                    <hr class="blue-hr">

                    <div class="row form-group">
                        <div class="col col-md-12">
                            <img src="images/in-logo.jpg" alt=""/>
                            <br>
                            <br>
                        </div>
                    </div>
                    @foreach($rooms->chunk(6) as $room)
                        <div class="row form-group">
                        @foreach($room as $item)
                        <div class="col col-md-2">
                            <label class="checkbox">
                                {{ Form::checkbox('room[]', $item->room_no, false, ['id'=>'inline-checkbox', 'class' => $item->status ? 'room available' : 'room', $item->status ? '' : 'disabled']) }} 
                                <span class="text">{{$item->room_no}}</span>
                                <span class="check"></span>
                            </label>
                        </div>
                        @endforeach 
                        </div>
                    @endforeach
                    <br>
                    <hr class="blue-hr">
                        
                
            </div>
            <div class="card-footer">
               <!-- <button type="submit" class="btn btn-primary btn-lg fright">
                    <i class="fa fa-forward"></i> Next
                </button> -->
                {{ Form::submit('Next',array('class' => 'btn btn-primary btn-lg fright')) }}
            </div>
        </div>
        {{ Form::close() }}



    </div>
</div>
@stop

@section('scripts')
	<script type="text/javascript">

	</script>
@stop