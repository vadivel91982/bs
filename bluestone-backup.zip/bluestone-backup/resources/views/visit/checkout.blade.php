@extends('layouts.master')
@section('title')
    {{"Check Out Form"}}
@stop

@section('content')

<div class="row">
    <div class="col-md-12">
        <!-- DATA TABLE -->
        <div class="table-data__tool">
            <div class="table-data__tool-left">
                <h3 class="title-5">Check Out Form</h3>
            </div>
            <div class="table-data__tool-right">
                <button onclick="javascript:location.href='{{route('visit.list')}}'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
                    <i class="fa fa-angle-left"></i>Back</button>
            </div>
        </div>
         <!-- <form action="" method="post" enctype="multipart/form-data" id="bs-form" class="form-horizontal"> -->
        {{ Form::open(['method' => 'post', 'route' => ['visit.billing', $getData->id], 'files'=>'true'])}}
        <div class="card">
            <div class="card-header">
                <strong>Check Out Form</strong>
            </div>
            <div class="card-body card-block GRC">
            
                    <div class="row form-group">
                        <div class="col col-md-4">
                            <img src="images/Print-logo.jpg" alt=""/>
                        </div>
                        <div class="col col-md-5"></div>
                        <div class="col col-md-3 gstin-right">
                                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                    <colgroup>
                                        <col width="30%">
                                        <col width="5%">
                                        <col width="65%">
                                    </colgroup>
                                    <tr>
                                        <td>GSTIN</td>
                                        <td>:</td>
                                        <td>34AYOPK2790F1Z8</td>
                                    </tr>
                                    <tr>
                                        <td>G.R.C No.</td>
                                        <td>:</td>
                                        <td>3659</td>
                                    </tr>
                                    <tr>
                                        <td>Room No.</td>
                                        <td>:</td>
                                        <td>{{ $getData->room_no }}</td>
                                    </tr>
                                    <tr>
                                        <td>Date</td>
                                        <td>:</td>
                                        <td>{{ date('m/d/Y H:i A', strtotime($getData->arrival_date)) }}</td>
                                    </tr>
                                    <tr>
                                        <td>Check Out</td>
                                        <td>:</td>
                                        <td>{{ date('m/d/Y H:i A') }}</td>
                                    </tr>
                                </table>
                        </div>
                    </div>
                    <hr class="blue-hr">
                    
                    <div class="row form-group">
                        <div class="col col-md-12 text-center">
                            <h2>Guest Registration Card</h2>
                        </div>
                        <div class="col col-md-12">
                        
                            <div class="profile profile-edit">
                                <img src="upload/customer/01.jpg" alt="" class="preview--rounded">
                            </div>
                        
                        </div>											
                    </div>
                
                    
                    <div class="row form-group">
                        <div class="col col-md-4">
                            <label for="text-input" class=" form-control-label">Full Name</label>
                            <p>{{ $getData->name }}</p>
                        </div>
                        <div class="col col-md-4">
                            <label for="mobile-input" class=" form-control-label">Mobile</label>
                            <p>{{ $getData->phone }}</p>
                        </div>
                        <div class="col col-md-4">
                            <label for="email-input" class=" form-control-label">Email</label>
                            <p>{{ $getData->email }}</p>
                        </div>
                    </div>
                    
                    <div class="row form-group">
                        <div class="col col-md-4">
                            <div class="row form-group">
                                <div class="col col-md-12">
                                    <label for="textarea-input" class=" form-control-label">Address</label>
                                    <p>{{ $getData->address }}</p>
                                </div>
                            </div>
                            
                        </div>

                        <div class="col col-md-8">
                            <div class="row form-group">
                                <div class="col col-md-6">
                                    <label for="company-input" class=" form-control-label">Company</label>
                                    <p>{{ $getData->company }}</p>
                                </div>
                                <div class="col col-md-6">
                                    <label for="visit-input" class=" form-control-label">Purpose of Visit</label>
                                    <p>{{ $getData->purpose }}</p>
                                </div>
                                
                            </div>
                            <div class="row form-group">
                                <div class="col col-md-6">
                                    <label for="vehicle-input" class=" form-control-label">Vehicle No.</label>
                                    <p>{{ $getData->vehicle }}</p>
                                </div>
                                <div class="col col-md-6">
                                    <label for="person-input" class=" form-control-label">No. of Person</label>
                                    <div class="row form-group">
                                        <div class="col col-md-6">
                                            <p><span class="inner">Adult :</span> {{ $getData->adult }}</p>
                                        </div>
                                        <div class="col col-md-6">
                                            <p><span class="inner">Child :</span> {{ $getData->child }}</p>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="row form-group">	
                                
                                <div class="col col-md-6">
                                    <label for="person-input" class=" form-control-label">ID Proof</label>
                                    <div class="row form-group">
                                        <div class="col col-md-12">
                                            <p><span class="inner">{{ $getData->proof_type }} :</span> {{ $getData->proof }}</p>
                                        </div>																
                                    </div>
                                </div>
                                <div class="col col-md-6">
                                    <div class="profile2 profile-edit">
                                        <img src="upload/aadhaar/01.jpg" alt="" class="preview2">
                                    </div>
                                </div>
                                
                                
                            </div>
                        </div>
                    </div>
                    
                    <hr class="blue-hr">

                    <div class="row form-group">
                        <div class="col col-md-12 text-center">
                            <h2>Additional Information for Foreigners Only</h2>
                        </div>
                        <div class="col col-md-12">
                        
                            <div class="profile3 profile-edit">														
                                <img src="upload/No-image.jpg" alt="" class="preview3">
                            </div>
                        
                        </div>											
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-4">
                            <label for="nationality-input" class=" form-control-label">Nationality</label>
                            <p>{{ $getData->frgn_nationality }}</p>
                        </div>
                        <div class="col col-md-4">
                            <label for="birth-input" class=" form-control-label">Date of Birth</label>
                            <p>{{ $getData->frgn_dob }}</p>
                        </div>
                        <div class="col col-md-4">
                            <label for="passport-input" class=" form-control-label">Passport No.</label>
                            <p>{{ $getData->frgn_passport }}</p>
                        </div>
                        
                    </div>
                    
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="issue-input" class=" form-control-label">Date & Place of Issue</label>
                            <p>{{ $getData->frgn_date_place }}</p>
                        </div>
                        <div class="col col-md-3">
                            <label for="validity-input" class=" form-control-label">Validity</label>
                            <p>{{ $getData->frgn_validity }}</p>
                        </div>
                        <div class="col col-md-3">
                            <label for="local-input" class=" form-control-label">Local Contact Address or Phone</label>
                            <p>{{ $getData->frgn_local_address }}</p>
                        </div>
                        <div class="col col-md-3">
                            <label class=" form-control-label">Employed in India?</label><br>
                            <p>{{ $getData->frgn_employed }}</p>
                        </div>
                        
                    </div>
                    
                    <hr class="blue-hr">

                    <div class="row form-group guest-inst">
                        <div class="col col-md-8">
                            <ul>
                                <li>The Management does not take responsiblity for the valuables left in the room.</li>
                                <li><b>Check-in 12 noon / check-out 11 Am</b></li>
                                <li>I have gone through the terms and conditions governing my stay in hotel and I agree to abide by them.</li>
                            </ul>
                        </div>
                        <div class="col col-md-4 text-right">
                            <h4><span>Guest Signature</span></h4>
                        </div>
                    </div>

                    <hr class="blue-hr">
                    <div class="row form-group">
                        <div class="col col-md-12 text-center">
                            <h2>Office Use only</h2>
                        </div>
                    </div>
                    <div class="row form-group guest-inst">
                        <div class="col col-md-8">
                            <div class="row form-group">
                                <div class="col col-md-6">
                                    <label for="occupancy-input" class=" form-control-label">Occupancy</label><br>
                                    <p>{{ $getData->ocpy_single }} {{ $getData->ocpy_double }} </p>
                                </div>
                                <div class="col col-md-6">
                                    <label for="occupancy-input" class=" form-control-label">Type of Room</label><br>
                                    <p>{{ $getData->room_type_ac }} {{ $getData->room_type_nonac }}</p>
                                </div>
                            </div>

                            <div class="row form-group">
                                
                                <div class="col col-md-6">
                                    <label for="settlement-input" class=" form-control-label">Advance</label>
                                    <p>{{ $getData->advance }}/-</p>
                                </div>
                                <div class="col col-md-6">
                                    <label for="voucher-input" class=" form-control-label">Receipt No</label>
                                    <p>{{ $getData->receipt_no }}</p>
                                </div>

                            </div>

                        </div>
                        <div class="col col-md-4 text-right">
                            <h4><span>Front Office Assistant</span></h4>
                        </div>

                    </div>	
                                                                
                    <hr class="blue-hr">
                    <div class="row form-group">
                        <div class="col col-md-12 text-center">
                            <h2>Room Billing</h2>
                        </div>
                    </div>
                    
                    <div class="row form-group">												
                            <div class="col col-md-2">
                                <label for="settlement-input" class=" form-control-label">Service</label>
                            </div>
                            <div class="col col-md-2">
                                <label for="voucher-input" class=" form-control-label">Amount</label>
                            </div>
                            <div class="col col-md-2">
                                <label for="voucher-input" class=" form-control-label">GST</label>
                            </div>
                            <div class="col col-md-1">
                                <label for="voucher-input" class=" form-control-label">CGST(%)</label>
                            </div>
                            <div class="col col-md-1">
                                <label for="voucher-input" class=" form-control-label">SGST(%)</label>
                            </div>
                            <div class="col col-md-3">
                                <label for="voucher-input" class=" form-control-label">Total</label>
                            </div>
                            <div class="col col-md-1">
                                <label for="voucher-input" class="add-label form-control-label">                                    
                                </label>												
                            </div>
                        </div>
                        <div class="row form-group input_fields_wrap">												
                            <div class="col col-md-2">
                                <input type="text" id="settlement-input" name="bs_service[]" class="form-control">
                            </div>
                            <div class="col col-md-2 bspricewrapper">
                                <input type="text" id="settlement-input bsprice" name="bs_price[]" class="form-control bsprice">
                            </div>
                            <div class="col col-md-2 gstwrapper">
                                <select name="bs_gst[]" id="person-input" class="form-control gstper">
                                    <!-- <option value="0">Select GST</option> -->
                                    <option value="6">6%</option>
                                    <option selected value="12">12%</option>
                                    <option value="18">18%</option>
                                </select>
                            </div>
                            <div class="col col-md-1 bscgstwrapper">
                                <input disabled type="text" id="settlement-input" name="bs_cgst[]" value="6" class="form-control cgst">
                            </div>
                            <div class="col col-md-1 bssgstwrapper">
                                <input disabled type="text" id="settlement-input" name="bs_sgst[]" value="6" class="form-control sgst">
                            </div>
                            <div class="col col-md-3 bstotalwrapper">
                                <input type="text" id="settlement-input" name="bs_total[]"  class="form-control bstotal">
                            </div>                            
                            <input type="button" id="settlement-input" value="+" class="col col-md-1 btn btn-primary add-btn add_field_button">
                        </div>
                        <hr class="blue-hr">
                        <div class="row form-group">												
                                <div class="col col-md-6">&nbsp;</div>												
                                <div class="col col-md-2">
                                    <h2 class="total">Grand Total</h2>
                                </div>
                                <div class="col col-md-3 bsgrandwrapper">													
                                    <input type="text" id="settlement-input" name="bs_grand_total" class="form-control grandTotal">
                                </div>
                                <div class="col col-md-1">&nbsp;</div>
                            </div>
                
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary btn-lg fright">
                    <i class="fa fa-floppy-o"></i> Save & Print
                </button>
            </div>
        </div>
        
        
        </form>
            
        <!-- END DATA TABLE -->
    </div>
</div>

@stop

@section('scripts')
    <script>
		$(document).ready(function() {           

            function total() {                
                var total = 0;
                $("div").siblings(".bstotalwrapper").find(".bstotal").not(this).each(function () {
                    var n = parseFloat($(this).val());
                    total += isNaN(n) ? 0 : n;
                    $('div').find('.bsgrandwrapper').find('.grandTotal').val(total.toFixed(2));
                });                
            }

            $(document).on('blur','.bsprice', function () {
                var val = parseFloat($(this).val());
                var gstVal = parseFloat($(this).parent("div").siblings(".gstwrapper").find(".gstper").val());
                var includegst = ((val * gstVal) / 100) + val;
                $(this).parent("div").siblings(".bstotalwrapper").find(".bstotal").val(includegst.toFixed(2));
                total();
            });

            $(document).on('change','.gstper', function () {
                var gstval = parseFloat($(this).val());
                var gst = parseFloat(gstval / 2);
                var price = $(this).parent("div").siblings(".bspricewrapper").find(".bsprice").val();
                var inclgst = parseFloat(((price * gstval) / 100)) + parseFloat(price);
                $(this).parent("div").siblings(".bscgstwrapper").find(".cgst").val(gst);
                $(this).parent("div").siblings(".bssgstwrapper").find(".sgst").val(gst);
                $(this).parent("div").siblings(".bstotalwrapper").find(".bstotal").val(inclgst.toFixed(2));
                total();
            });
              
            var max_fields = 10; //maximum input boxes allowed
            var wrapper    = $(".input_fields_wrap"); //Fields wrapper
            var add_button = $(".add_field_button"); //Add button ID
            
            var x = 1; //initlal text box count
            $(add_button).click(function(e){ //on add input button click
                e.preventDefault();
                
                if(x < max_fields){ //max input box allowed
                    x++; //text box increment
                    $(wrapper).append('<div class="set"><br><div class="col col-md-2">'+
                        '<input type="text" id="settlement-input" name="bs_service[]" class="form-control"></div>'+
                        '<div class="col col-md-2 bspricewrapper">'+
                        '<input type="text" id="settlement-input bsprice" name="bs_price[]" class="form-control bsprice"></div>'+
                        '<div class="col col-md-2 gstwrapper">'+
                            '<select name="bs_gst[]" id="person-input gstper" class="form-control gstper">'+
                                '<option value="6">6%</option>'+
                                '<option selected value="12">12%</option>'+
                                '<option value="18">18%</option>'+
                            '</select>'+
                        '</div>'+
                        '<div class="col col-md-1 bscgstwrapper">'+
                            '<input type="text" disabled id="settlement-input" name="bs_cgst[]" value="6" class="form-control cgst">'+
                        '</div>'+
                        '<div class="col col-md-1 bssgstwrapper">'+
                            '<input type="text" disabled id="settlement-input" name="bs_sgst[]" value="6" class="form-control sgst">'+
                        '</div>'+
                        '<div class="col col-md-3 bstotalwrapper">'+
                            '<input type="text" id="settlement-input bstotal" name="bs_total[]" class="form-control bstotal">'+
                        '</div>'+
                            '<input type="button" id="settlement-input" value="-" class="col col-md-1 btn btn-primary add-btn remove_field">'+
                    '</div>'); //add input box
                }
            });
			
			$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
				e.preventDefault(); 
                $(this).parent('.set').remove(); 
                x--;
			});

            // $('input').on({
            //     focus: function () {
            //         if (this.value == '0') this.value = '';
            //     },
            //     blur: function () {
            //         if (this.value == '') this.value = '0';
            //     }
            // });
		});
	</script> 
@stop