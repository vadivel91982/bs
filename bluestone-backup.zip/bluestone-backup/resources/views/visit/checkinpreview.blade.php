@extends('layouts.pdfmaster')
@section('title')
    {{"Preview Check In"}}
@stop

@section('content')
        <!-- PAGE CONTAINER-->									
        <div class="page-container" style="width:96%;margin:0px auto; auto;border: 1px solid #ddd;padding-left: 2%;padding-right:2%;">
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">										
						<div class="row">
                            <div class="col-md-12" >
								<form action="" method="post" enctype="multipart/form-data" class="form-horizontal">                                
								<div class="card">									
									<div class="card-body card-block GRC" style="margin-top:3%;">
											<div class="row form-group" style="width:100%;">
											<div style="width: 100%;">
												 <div style="float: left; width: 60%;"><img src="images/Print-logo.jpg" alt=""/></div>												 
												 <div style="float:left; width: 40%;"><table width="100%" cellpadding="0" cellspacing="0" border="0">
																		<colgroup>
																			<col width="30%">
																			<col width="5%">
																			<col width="65%">
																		</colgroup>
																		<tr>
																			<td  style="font-family: poppins;font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;">GSTIN</td>
																			<td style="font-family: poppins; font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;    font-family: poppins;">:</td>
																			<td style="font-family: poppins; font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;">34AYOPK2790F1Z8</td>
																		</tr>
																		<tr >
																			<td style="font-size: 16px;font-weight: 700;color: #003cd4; height: 40px;    font-family: poppins;">G.R.C No.</td>
																			<td style="font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;    font-family: poppins;">:</td>
																			<td style="font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;    font-family: poppins;">3659</td>
																		</tr>
																		<tr>
																			<td style="font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;    font-family: poppins;">Room No.</td>
																			<td style="font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;    font-family: poppins;">:</td>
																			<td style="font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;    font-family: poppins;">365</td>
																		</tr>
																		<tr>
																			<td style="font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;font-family: poppins;">Date</td>
																			<td style="font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;font-family: poppins;">:</td>
																			<td style="font-size: 16px;font-weight: 700;color: #003cd4;height: 40px;    font-family: poppins;">06/15/18 - 11:50 AM</td>
																		</tr>
																	</table></div>
																<br style="clear: left;" />
											</div>
												<div class="col col-md-4" style="width:50%;float:left;"> </div>												
												<div class="col col-md-3 gstin-right" style="width:50%;"> </div>
											</div>
											<hr class="blue-hr" style="margin-top: 2rem !important;margin-bottom: 2rem !important; border-top: 3px solid #003cd4;">											
											<div class="row form-group">
												<div class="col col-md-12" style="text-align: center!important;">
													<h2 style="color: #003cd4;text-transform: uppercase;font-weight: 700; font-family: poppins; font-size: 30px;">Guest Registration Card</h2>
												</div>
												<div class="col col-md-12" style="margin-bottom:3%;">		
													<div class="profile3 profile-edit" style="    position: relative;font-family: 'HelveticaNeueLTPro-Roman', sans-serif;font-size: 85%;width: 300px;margin: 0 auto;text-align: center;overflow: hidden; ">	
														<img src="upload/customer/01.jpg" alt="" class="preview3" style="    width: 160px;height: 160px;border-radius: 50%;border: 3px solid #003cd4;top: 5px;left: 20%;">
													</div>												
												</div>											
											</div>																					
											<div class="row form-group" style="margin-bottom: 1rem;width:100%;">
												<div class="col col-md-4" style="float:left;width:33.3%;    margin-bottom: 3%;">
													<label for="text-input" class=" form-control-label" style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">Full Name</label>
													<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">Gnanasekar Annadurai</p>
												</div>
												<div class="col col-md-4" style="float:left;width:33.3%;    margin-bottom: 3%;">
													<label for="mobile-input" class=" form-control-label" style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">Mobile</label>
												<p style="    color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">8870826620</p>
												</div>
												<div class="col col-md-4" style="float:left;width:33.3%;    margin-bottom: 3%;">
													<label for="email-input" class=" form-control-label " style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">Email</label>
													<p style="    color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">gnanasekar.annadurai@gmail.com</p>
												</div>
											</div>											
											<div class="row form-group" style="margin-bottom: 1rem;width:100%;">
												<div class="col col-md-4" style="float:left;width:33.3%;">
													<div class="row form-group">
														<div class="col col-md-12">
															<label for="textarea-input" class=" form-control-label" style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">Address</label>
															<p style="    color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">No 31, Marutham Street, <br>Solai Nagar, Muthialpet, <br>Pondicherry - 605003</p>
														</div>
													</div>													
												</div>
												<div class="col col-md-8" style="float:left;width:66.6%;">
													<div class="row form-group">
														<div class="col col-md-6" style="float:left;width:50%;">
															<label for="company-input" class=" form-control-label" style="     font-family: poppins;   color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block; margin-bottom: .5rem;">Company</label>
															<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">Pluselve Digital Soltuions Pvt Ltd</p>
														</div>
														<div class="col col-md-6" style="float:left;width:50%;    margin-bottom: 2rem;">
															<label for="visit-input" class=" form-control-label" style="       font-family: poppins; color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">Purpose of Visit</label>
															<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">Business Meeting</p>
														</div>														
													</div>
													<div class="row form-group" style=" margin-bottom: 3%;">
														<div class="col col-md-6" style="float:left;width:50%;    margin-bottom: 3%;">
															<label for="vehicle-input" class=" form-control-label" style="     font-family: poppins;   color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">Vehicle No.</label>
															<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">PY 01 AP 6575</p>
														</div>
														<div class="col col-md-6" style="float:left;width:50%;    margin-bottom: 3%;">
															<label for="person-input" class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;     font-family: poppins;   display: inline-block;margin-bottom: .5rem;">No. of Person</label>			
															<div class="row form-group">	
															<div class="col col-md-6" style="width:50%;float:left;">
																	<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;"><span class="inner" style="    color: #003cd4;">Adult :</span> 1</p>
																</div>
															<div class="col col-md-6" style="width:50%;float:left;">
																	<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;"><span class="inner" style="    color: #003cd4;">Child :</span> NIL</p>
																</div>
																
																</div>															
														</div>
													</div>
													<div class="row form-group">														
														<div class="col col-md-6" style="float:left;width:50%;    margin-bottom: 5%;">
															<label for="person-input" class=" form-control-label" style="       font-family: poppins; color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">ID Proof</label>
															<div class="row form-group">
																<div class="col col-md-4" style="float:left;width:100%;">
																	<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;"><span class="inner" style="color: #003cd4;">Aadhaar :</span> 2564 5669 4859</p>
																</div>
															</div>
														</div>
														<div class="col col-md-6" style="float:left;width:50%;    margin-bottom: 5%;">
															<div class="profile3 profile-edit" style="    position: relative;font-family: 'HelveticaNeueLTPro-Roman', sans-serif;font-size: 85%;width: 300px;margin: 0 auto;text-align: center;overflow: hidden; ">			
														<img src="upload/aadhaar/01.jpg" alt="" class="preview3" style="   width: 200px;height: 130px;border: 3px solid #003cd4;top: 15px;">
													</div>
														</div>
													</div>
												</div>
											</div>											
											<hr class="blue-hr" style="margin-top: 2rem !important;margin-bottom: 2rem !important;    border-top: 3px solid #003cd4;">
											<div class="row form-group">
												<div class="col col-md-12 text-center" style="text-align:center;">
													<h2 style="color: #003cd4;text-transform: uppercase;font-weight: 700;     font-family: poppins;   font-size: 30px;">Additional Information for Foreigners Only</h2>
												</div>																				
											</div>											
											<div class="row form-group">												
												<div class="col col-md-12" style="margin-bottom:3%;">
												<div class="profile3 profile-edit" style="    position: relative;font-family: 'HelveticaNeueLTPro-Roman', sans-serif;font-size: 85%;width: 300px;margin: 0 auto;text-align: center;overflow: hidden; ">														
														<img src="upload/No-image.jpg" alt="" class="preview3" style="   width: 200px;height: 130px;border: 3px solid #003cd4;top: 15px;">
													</div>				
												</div>											
											</div>
											<div class="row form-group">
												<div class="col col-md-4" style="float:left;width:33.3%;    margin-bottom: 3%;">
													<label for="nationality-input" class=" form-control-label" style="       font-family: poppins; color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">Nationality</label>
													<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">NIL</p>
												</div>
												<div class="col col-md-4" style="float:left;width:33.3%;  margin-bottom: 3%;">
													<label for="birth-input" class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;     font-family: poppins;   display: inline-block;margin-bottom: .5rem;">Date of Birth</label>
													<div class="input-group">
													<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">NIL</p>
														<div class="input-group-addon">
															<i class="fa fa fa-calendar"></i>
														</div>
													</div>
												</div>
												<div class="col col-md-4" style="float:left;width:33.3%;  margin-bottom: 3%;">
													<label for="passport-input" class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;      font-family: poppins;  display: inline-block;margin-bottom: .5rem;">Passport No.</label>
													<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">NIL</p>
												</div>												
											</div>											
											<div class="row form-group">
												<div class="col col-md-3" style="float:left;width:25%">
													<label for="issue-input" class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;     font-family: poppins;   display: inline-block;
    margin-bottom: .5rem;">Date & Place of Issue</label>
													<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">NIL</p>
												</div>
												<div class="col col-md-3" style="float:left;width:25%">
													<label for="validity-input" class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;     font-family: poppins;   display: inline-block;margin-bottom: .5rem;">Validity</label>
													<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">NIL</p>
												</div>
												<div class="col col-md-3" style="float:left;width:25%">
													<label for="local-input" class=" form-control-label" style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">Contact Address or Phone</label>
													<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">NIL</p>
												</div>
												<div class="col col-md-3" style="float:left;width:25%">
													<label class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;    font-family: poppins;    display: inline-block;margin-bottom: 1.5rem;">Employed in India?</label><br>
													<div class="form-check-inline form-check" style="      margin-bottom: 3.25rem;  display: -ms-inline-flexbox;display: inline-flex;-ms-flex-align: center;align-items: center;padding-left: 0;margin-right: .75rem;">
														<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">NIL</p>
													</div>
												</div>												
											</div>											
											<hr class="blue-hr" style="margin-top: 2rem !important;margin-bottom: 2rem !important;    border-top: 3px solid #003cd4;">
											<div class="row form-group guest-inst" style="    margin-bottom: 1rem;">
												<div class="col col-md-12" style="width:100%;float:left;">
													<ul style="padding-left:0;">
														<li style="    list-style-type: decimal;margin-left: 20px;color: #003cd4;padding-left: 5px;padding-bottom: 10px;font-size:18px;    font-family: poppins;">The Management does not take responsiblity for the valuables left in the room.</li>
														<li style="    list-style-type: decimal; margin-left: 20px; color: #003cd4; padding-left: 5px; padding-bottom: 10px;font-size:18px;    font-family: poppins;"><b>Check-in 12 noon / check-out 11 Am</b></li>
														<li style="    list-style-type: decimal;margin-left: 20px;color: #003cd4;padding-left: 5px;padding-bottom: 10px;font-size:18px;    font-family: poppins;">I have gone through the terms and conditions governing my stay in hotel and I agree to abide by them.</li>
													</ul>
												</div>
												<div class="col col-md-12 text-right" style="width:100%; text-align: right!important;">
													<h4 style="    color: #003cd4; position: relative; height: 100%;font-size:20px;    font-family: poppins;"><span>Guest Signature</span></h4>
												</div>
											</div>
											<hr class="blue-hr" style="margin-top: 2rem !important;margin-bottom: 2rem !important;    border-top: 3px solid #003cd4;"> 
											<div class="row form-group">
												<div class="col col-md-12 text-center" style="text-align:center;">
													<h2 style="color: #003cd4;text-transform: uppercase;font-weight: 700;    font-family: poppins;">Office Use only</h2>
												</div>
											</div>										
											<div class="row form-group guest-inst" style="margin-bottom:5%;">
												<div class="col col-md-8" style="width:66.6%">
													<div class="row form-group">
														<div class="col col-md-6" style="width:50%;float:left;margin-bottom:3%;" >
															<label for="occupancy-input" class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;margin-bottom: .5rem;    font-family: poppins;">Occupancy</label><br>
															<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">SINGLE</p>
														</div>
														<div class="col col-md-6" style="width:50%;float:left;margin-bottom:3%;" >
															<label for="occupancy-input" class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;     font-family: poppins;">Type of Room</label>
															<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">A/C</p>															
														</div>
													</div>
													<div class="row form-group">														
														<div class="col col-md-6" style="width:50%;float:left;">
															<label for="settlement-input" class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;    font-family: poppins;">Advance</label>
															<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">1000/-</p>
														</div>
														<div class="col col-md-6" style="width:50%;float:left;">
															<label for="voucher-input" class=" form-control-label" style="    color: #003cd4;text-transform: uppercase;font-weight: 700;    font-family: poppins;">Receipt No</label>
															<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">350</p>
														</div>
													</div>
												</div>
												<div class="col col-md-4 text-right" style="width:100%;text-align:right;padding-top:11%;margin-bottom:3%;">
													<h4 style="color: #003cd4;position: relative;height: 100%;font-size:20px;    font-family: poppins;"><span>Front Office Assistant</span></h4>
												</div>
											</div>
									<hr class="blue-hr" style="margin-top: 2rem !important;margin-bottom: 2rem !important;    border-top: 3px solid #003cd4;">
											<div class="row form-group guest-inst" style="margin-bottom:15%;">
											<div class="row form-group">
												<div class="col col-md-12 text-center" style="text-align:center;">
													<h2 style="color: #003cd4;text-transform: uppercase;font-weight: 700;     font-family: poppins;   font-size: 30px;">ROOM BILLING</h2>
												</div>																			
											</div>											
											<div class="row form-group" style="margin-bottom: 1rem;width:100%;">
												<div class="col col-md-4" style="float:left;width:20%;    margin-bottom: 3%;">
													<label for="text-input" class=" form-control-label" style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">SERVICE</label>
													<p style="color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">Room Rent</p>
												</div>
												<div class="col col-md-4" style="float:left;width:20%;    margin-bottom: 3%;">
													<label for="mobile-input" class=" form-control-label" style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">AMOUNT</label>
												<p style="    color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">1500</p>
												</div>
												<div class="col col-md-4" style="float:left;width:20%;    margin-bottom: 3%;">
													<label for="email-input" class=" form-control-label " style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">GST</label>
													<p style="    color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">12%</p>
												</div>
												<div class="col col-md-4" style="float:left;width:20%;    margin-bottom: 3%;">
													<label for="email-input" class=" form-control-label " style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">CGST</label>
													<p style="    color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">6%</p>
												</div>
												<div class="col col-md-4" style="float:left;width:10%;    margin-bottom: 3%;">
													<label for="email-input" class=" form-control-label " style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">SGST</label>
													<p style="    color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">6%</p>
												</div>
												<div class="col col-md-4" style="float:left;width:10%;    margin-bottom: 3%;">
													<label for="email-input" class=" form-control-label " style="      font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">TOTAL</label>
													<p style="    color: #000;font-weight: 700;font-size: 20px;font-family:poppins;">1650</p>
												</div>
											</div>
											<hr class="blue-hr" style="margin-top: 2rem !important;margin-bottom: 2rem !important;    border-top: 3px solid #003cd4;">
													<div class="col col-md-12" style="float:right;width:100%;">					
													<p style="float:right;color: #000;font-weight: 700;font-size: 20px;font-family:poppins;padding-left:2%;padding-top:3px;">4650</p>
															<h2 class="total" style="float:right;font-family: poppins;  color: #003cd4;text-transform: uppercase;font-weight: 700;    display: inline-block;margin-bottom: .5rem;">Grand Total :</h2>
												</div>
									</div>									
								</div>																
								</form>									
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>
</div>
@stop

@section('scripts')
	<script type="text/javascript">
               
    </script> 
@stop