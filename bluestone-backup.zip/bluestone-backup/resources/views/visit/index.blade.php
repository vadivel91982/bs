@extends('layouts.master')
@section('title')
    {{"Admin List"}}
@stop

@section('content')
<div class="row">
    <div class="col-md-12">
        <!-- DATA TABLE -->
        
        <div class="table-data__tool">
            <div class="table-data__tool-left">
                <h3 class="title-5">CheckIn List</h3>
                <div class="rs-select2--light rs-select2--md">
                    <!-- <select class="js-select2" name="property">
                        <option selected="selected">All Properties</option>
                        <option value="">Option 1</option>
                        <option value="">Option 2</option>
                    </select>
                    <div class="dropDownSelect2"></div> -->
                </div>
                <div class="rs-select2--light rs-select2--sm">
                    <!-- <select class="js-select2" name="time">
                        <option selected="selected">Today</option>
                        <option value="">3 Days</option>
                        <option value="">1 Week</option>
                    </select>
                    <div class="dropDownSelect2"></div> -->
                </div>
                <!-- <<button class="au-btn-filter">
                    <i class="zmdi zmdi-filter-list"></i>filters</button> -->
            </div>
            <div class="table-data__tool-right">
                <button onclick="javascript:location.href='{{route('visit.create')}}'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
                    <i class="zmdi zmdi-plus"></i>Create Check In</button>
                <div class="rs-select2--dark rs-select2--sm rs-select2--dark2">
                    <select class="js-select2" name="type">
                        <option selected="selected">Export</option>
                        <option value="">PDF</option>
                        <option value="">Excel</option>
                    </select>
                    <div class="dropDownSelect2"></div>
                </div>
            </div>
        </div>
        <div class="table-responsive table-responsive-data2">
        <table class="table table-bordered" id="visit-table">
            <thead>
                <tr>
                    <th>FORM NO</th>
                    <th>NAME</th>
                    <th>CHECK IN DETAILS</th>
                    <th></th>
                    <!-- <th>ADMIN</th> -->
                    <th>DATE / TIME</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
        </div>
        <!-- END DATA TABLE -->
    </div>
</div>
@stop

@section('scripts')
	<script type="text/javascript">
		$(function() {
            $('#visit-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: '{!! route('visitdatatables.data') !!}',
                columns: [
                    { data: 'receipt_no', name: 'receipt_no' },
                    { data: 'name', name: 'name' },
                    { data: 'email', name: 'email' },
                    { data: 'phone', name: 'phone' },
                    // { data: 'admin_id', name: 'admin_id' },
                    { data: 'arrival_date', name: 'arrival_date' },
                    { data: 'action', name: 'action', orderable: false, searchable: false}
                ]
            });
        });
	</script>
@stop