@if ($message = Session::get('success'))
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<div class="alert alert-success">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<ul>
			<li>{{ $message }}</li>
		</ul>
	</div>
</div>
@endif

@if ($message = Session::get('error'))
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<div class="alert alert-danger">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<ul>
			<li>{{ $message }}</li>
		</ul>
	</div>
</div>
@endif

@if ($message = Session::get('warning'))
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<div class="alert alert-warning">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<ul>
			<li>{{ $message }}</li>
		</ul>
	</div>
</div>
@endif

@if ($message = Session::get('info'))
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<div class="alert alert-info">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<ul>
			<li>{{ $message }}</li>
		</ul>
	</div>
</div>
@endif

{{-- @if ($errors->any()) --}}
<!-- <div class="col-xs-10 col-sm-10 col-md-10 alert alert-danger">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	Please check the form below for errors
</div> -->
{{--  @endif --}}