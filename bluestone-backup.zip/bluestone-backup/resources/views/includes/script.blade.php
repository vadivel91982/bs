    <script src="../../theme/jquery-3.2.1.min.js"></script>
    
    <script src="../../theme/bootstrap/js/bootstrap-datetimepicker.min.js"></script>
    <script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="../../theme/bootstrap-4.1/popper.min.js"></script>
    <script src="../../theme/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="../../theme/slick/slick.min.js">
    </script>
    <script src="../../theme/wow/wow.min.js"></script>
    <script src="../../theme/animsition/animsition.min.js"></script>
    <script src="../../theme/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="../../theme/counter-up/jquery.waypoints.min.js"></script>
    <script src="../../theme/counter-up/jquery.counterup.min.js">
    </script>
    <script src="../../theme/circle-progress/circle-progress.min.js"></script>
    <script src="../../theme/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="../../theme/chartjs/Chart.bundle.min.js"></script>
    <script src="../../theme/select2/select2.min.js"></script>
    <script src="../../theme/webcamjs/webcam.min.js"></script>
    <script src="../../theme/main.js"></script>

    