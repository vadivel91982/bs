<!--<script src="../../js/vendor.js"></script>
<script src="../../js/app.js"></script>


<script src="../../js/dataTables.buttons.min.js"></script>
<script src="../../js/buttons.html5.min.js"></script>
<script src="../../js/pdfmake.min.js"></script>
<script src="../../js/vfs_fonts.js"></script> -->
<div class="row">
    <div class="col-md-12">
        <div class="copyright">
            <p>Copyright © 2018 BlueStone. All rights reserved. Template by <a href="https://www.pluselve.com/">Pluselve Digital Soltuions</a>.</p>
        </div>
    </div>
</div>



