@extends('layouts.master')
@section('title')
    {{"Change Password"}}
@stop

@section('content')
<div class="row">
	<div class="col-md-12">
		<!-- DATA TABLE -->
		<div class="table-data__tool">
			<div class="table-data__tool-left">
				<h3 class="title-5">Change Password</h3>
			</div>
			<div class="table-data__tool-right">
				<button onclick="javascript:location.href='admin.html'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
		</div>
		
		
		<div class="card">
			<div class="card-header">
				<strong>Admin Form</strong>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					@if (count($errors) > 0)
					<div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<ul>
							@foreach ($errors->all() as $error)
							<li>{{ $error }}</li>
							@endforeach
						</ul>
					</div>
					@endif
				</div>
			</div>
			{{ Form::open(['method' => 'POST', 'route' => ['account.change-password-store']])}}
			<div class="card-body card-block">
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('password', 'Password', ['class' => 'optionLabel']) }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::password('currentPassword', ['class' => 'au-input au-input--full', 'placeholder' => 'Old Password']) }}
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('password_confirmation', 'Re-Enter Password', ['class' => 'optionLabel']) }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::password('newPassword', ['class' => 'au-input au-input--full', 'placeholder' => 'New Password']) }}
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('password_confirmation', 'Re-Enter Password', ['class' => 'optionLabel']) }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::password('confirmPassword', ['class' => 'au-input au-input--full', 'placeholder' => 'Re-Enter Password']) }}
					</div>
				</div>
			
		</div>
		<div class="card-footer">				
			{{ Form::submit('Submit',array('class' => 'btn btn-primary btn-lg')) }}
			{{ Form::submit('Reset',array('class' => 'btn btn-danger btn-lg')) }}
		</div>
		{{ Form::close() }}
			
		<!-- END DATA TABLE -->
	</div>
</div>	
@stop

@section('scripts')
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
@stop