@extends('layouts.master')
@section('title')
    {{trans('auth.forgot-password-title')}}
@stop

@section('content')
	<div class="container">
	@if (count($errors) > 0)
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<div class="alert alert-danger">
				<button type="button" class="close" data-dismiss="alert">×</button>
				<strong>Whoops!</strong> There were some problems with your input.<br><br>
				<ul>
					@foreach ($errors->all() as $error)
						<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		</div>			
	@endif
	
		<div class="login_box col-xs-12 col-sm-8 col-md-4">
			{{ Form::open(['method' => 'POST', 'route' => ['user.reset-password']])}}

				<div class="col-md-12">
					<div class="form-group">
						{{ Form::label('userName', trans('account.email'), ['class' => 'optionLabel']) }}<span>*</span>
						{{ Form::text('userName', Input::old('userName'), ['class' => 'form-control']) }}
						<p class="text-red">{!! $errors->first('userName') !!}</p>
					</div>					
				</div>
				<p></p>
				<div class="col-md-12" style="text-align: center;">
					<div class="col-md-6 col-xs-6" style="text-align: left;padding: 0;">
					{{ Form::submit(trans('account.reset-password'),array('class' => 'base_btn')) }}
					</div>							
				</div>
			{{ Form::close() }}
		</div>
	</div>
@stop

@section('scripts')
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
@stop