@extends('layouts.master')
@section('title')
    {{"Create New Admin"}}
@stop

@section('content')
<div class="row">
	<div class="col-md-12">
		<!-- DATA TABLE -->
		<div class="table-data__tool">
			<div class="table-data__tool-left">
				<h3 class="title-5">Create New Admin</h3>
			</div>
			<div class="table-data__tool-right">
				<button onclick="javascript:location.href='{{route('account.list')}}'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
		</div>
		
		
		<div class="card">
			<div class="card-header">
				<strong>Admin Form</strong>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					@if (count($errors) > 0)
					<div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<ul>
							@foreach ($errors->all() as $error)
							<li>{{ $error }}</li>
							@endforeach
						</ul>
					</div>
					@endif
				</div>
			</div>
			{{ Form::open(['method' => 'POST', 'route' => ['account.store'], 'files'=>'true'])}}
			<div class="card-body card-block">

				<div class="row form-group">
					<div class="col col-md-3">
					{{ Form::label('name', 'Name'), ['class' => 'optionLabel'] }}
					</div>
					<div class="col-12 col-md-9">
					{{ Form::text('name', Input::old('name'), ['class' => 'au-input au-input--full', 'placeholder' => 'Name']) }}
						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('email', 'Email Address'), ['class' => 'optionLabel'] }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::text('email', Input::old('email'), ['class' => 'au-input au-input--full', 'placeholder' => 'Email']) }}						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('phone', 'Phone'), ['class' => 'optionLabel'] }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::text('phone', Input::old('phone'), ['class' => 'au-input au-input--full', 'placeholder' => 'Phone']) }}
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('password', 'Password', ['class' => 'optionLabel']) }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::password('password', ['class' => 'au-input au-input--full', 'placeholder' => 'Password']) }}
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('password_confirmation', 'Re-Enter Password', ['class' => 'optionLabel']) }}  
					</div>
					<div class="col-12 col-md-9">
						{{ Form::password('password_confirmation', ['class' => 'au-input au-input--full', 'placeholder' => 'Re-Enter Password']) }}
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('status', 'Status', ['class' => 'optionLabel']) }}
					</div>
					<div class="col-12 col-md-9">
						<!-- <select name="select" id="select" class="form-control">
							<option value="0">Please select</option>
							<option value="1">Active</option>
							<option value="2">Inactive</option>
						</select> -->
						<?php $arr = ['' => 'Please select', '1' => 'Active', '2'=> 'Inactive']; ?>
						<select class="form-control" id='select' class='form-control' name="status">
							@foreach($arr as $key => $item)
							<option value="{{ $item }}"> {{ strtoupper($item) }}</option>
							@endforeach
						</select>
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						<!-- <label for="file-input" class=" form-control-label">Upload Photo</label> -->
						{{ Form::label('Upload Photo', 'Upload Photo', ['class' => 'form-control-label']) }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::file('image', ['id' => 'file-input', 'class' => 'form-control-file']) }}
						<!-- <input type="file" id="file-input" name="file-input" class="form-control-file"> -->
					</div>
				</div>
				{{ Form::hidden('role_id', '2') }}
				<!-- <div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('photo', 'Upload Photo', ['class' => 'optionLabel']) }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::file('image',  ['class' => 'form-control-file', 'id' => 'file-input']) }}						
					</div>
				</div> -->
			</div>
			<div class="card-footer">				
				{{ Form::submit('Submit',array('class' => 'btn btn-primary btn-lg')) }}
				{{ Form::submit('Reset',array('class' => 'btn btn-danger btn-lg')) }}
			</div>
			{{ Form::close() }}
		</div>
			
		<!-- END DATA TABLE -->
	</div>
</div>	
@stop

@section('scripts')
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
@stop