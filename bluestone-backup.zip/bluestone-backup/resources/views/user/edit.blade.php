@extends('layouts.master')
@section('title')
    {{"User Login"}}
@stop

@section('content')
<div class="row">
	<div class="col-md-12">
		<!-- DATA TABLE -->
		<div class="table-data__tool">
			<div class="table-data__tool-left">
				<h3 class="title-5">Edit Admin</h3>
			</div>
			<div class="table-data__tool-right">
				<button onclick="javascript:location.href='admin.html'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
		</div>
		
		
		<div class="card">
			<div class="card-header">
				<strong>Admin Form</strong>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					@if (count($errors) > 0)
					<div class="alert alert-danger">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<ul>
							@foreach ($errors->all() as $error)
							<li>{{ $error }}</li>
							@endforeach
						</ul>
					</div>
					@endif
				</div>
			</div>
			{{ Form::open(['method' => 'patch', 'route' => ['account.update',$user->id], 'files'=>'true'])}}
			<div class="card-body card-block">

				<div class="row form-group">
					<div class="col col-md-3">
					{{ Form::label('name', 'Name'), ['class' => 'optionLabel'] }}
					</div>
					<div class="col-12 col-md-9">
					{{ Form::text('name', $user->name, ['class' => 'au-input au-input--full', 'placeholder' => 'Name']) }}
						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('email', 'Email Address'), ['class' => 'optionLabel'] }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::text('email', $user->email, ['class' => 'au-input au-input--full', 'placeholder' => 'Email']) }}						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('phone', 'Phone'), ['class' => 'optionLabel'] }}
					</div>
					<div class="col-12 col-md-9">
						{{ Form::text('phone', $user->phone, ['class' => 'au-input au-input--full', 'placeholder' => 'Phone']) }}
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('status', 'Status', ['class' => 'optionLabel']) }}
					</div>
					<div class="col-12 col-md-9">						
						<?php $arr = ['' => 'Please select', '1' => 'Active', '2'=> 'Inactive']; ?>
						<select class="form-control" id='select' class='form-control' name="status">
							@foreach($arr as $key => $item)
								<option value="{{ $key }}" @if($user->status=== $key) selected='selected' @endif> {{ strtoupper($item) }}</option>
							@endforeach
						</select>						
					</div>
				</div>
				<div class="row form-group">
					<div class="col col-md-3">
						{{ Form::label('Upload Photo', 'Upload Photo', ['class' => 'form-control-label']) }}
					</div>
					<div class="col-12 col-md-9 image">						
						@if ("/images/customer/{{ $user->avatar }}")
							<img src="{{ URL::to('/') }}/images/customer/{{ $user->avatar }}" width="100" height="100">							
						@else
							<p>No image found</p>
						@endif
						<br/>
						<br/>
						<input type="file" name="image" value="{{ $user->avatar }}"/>
						<!-- {{ Form::file('image', ['id' => 'file-input', 'class' => 'form-control-file']) }} -->
					</div>
				</div>
				{{ Form::hidden('role_id', '2') }}
			</div>
			<div class="card-footer">				
				<!-- <i class="fa fa-dot-circle-o"></i> -->
				{{ Form::submit('Submit',array('class' => 'btn btn-primary btn-lg')) }}
				<!-- <i class="fa fa-ban"></i>  -->
				{{ Form::submit('Reset',array('class' => 'btn btn-danger btn-lg')) }}
			</div>
			{{ Form::close() }}
		</div>
			
		<!-- END DATA TABLE -->
	</div>
</div>	
@stop

@section('scripts')
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
@stop