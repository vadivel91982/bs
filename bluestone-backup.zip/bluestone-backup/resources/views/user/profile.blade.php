@extends('layouts.master')
@section('title')
    {{"User Profile"}}
@stop

@section('content')
<div class="row">
	<div class="col-md-12">
		<!-- DATA TABLE -->
		<div class="table-data__tool">
			<div class="table-data__tool-left">
				<h3 class="title-5">Profile</h3>
			</div>
			<div class="table-data__tool-right">
				<button onclick="javascript:location.href='{{route('account.list')}}'" class="au-btn au-btn-icon au-btn--orange au-btn--small">
					<i class="fa fa-angle-left"></i>Back</button>
			</div>
		</div>
		
		
		<div class="card">
			<div class="card-header">
				<strong>User Profile</strong>
			</div>
			

			<div class="card-body card-block">
				<div class="row form-group">
					<div class="col col-md-12">
						<div class="proile-img">
							<img widht="100" height="100" src="/images/customer/{{ Auth::user()->avatar }}" alt="{{ Auth::user()->name }}" />
						</div>
						<table width="50%">
							<tr>
								<td width="23%"><h5>{{ Form::label('name', 'Name'), ['class' => 'optionLabel'] }}</h5></td>
								<td width="2%">:</td>
								<td width="75%">{{$user->name}}</td>
							</tr>
							<tr>
								<td><h5>{{ Form::label('email', 'Email Address'), ['class' => 'optionLabel'] }}</h5></td>
								<td>:</td>
								<td>{{$user->email}}</td>
							</tr>
							<tr>
								<td><h5>{{ Form::label('phone', 'Phone'), ['class' => 'optionLabel'] }}</h5></td>
								<td>:</td>
								<td>{{$user->phone}}</td>
							</tr>
						</table>
					</div>
				</div>
				
			</div>
			<div class="card-footer">				
            {!! link_to_route('account.edit', 'Edit', ['id' => Auth::user()->id], ['class' => 'btn btn-primary btn-lg']) !!}				
			</div>
		</div>
			
		<!-- END DATA TABLE -->
	</div>
</div>	
@stop

@section('scripts')
	<script type="text/javascript">
		/*$(function () {
			$('.datepickerstart').datetimepicker({
			viewMode: 'years',
			format: 'DD/MM/YYYY'
			});
		});*/
	</script>
@stop