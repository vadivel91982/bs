<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">
	<link id="page_favicon" href="images/favicon.jpg" rel="icon" type="image/x-icon" />
<title>Preview Check In</title>
</head>
<body>       
        @yield('content') 

        @include('includes.script')
        @yield('scripts')
    </body>
</html>
<!-- end document-->