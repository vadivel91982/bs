<!doctype html>
<html>
    <head>
        @include('includes.head')
    </head>
    <body class="animsition">
        <div class="page-wrapper">
            @include('includes.header')
            @include('includes.sidebar')

            
                <!-- MAIN CONTENT-->
                @if(Illuminate\Support\Facades\Auth::check())
                <div class="main-content">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">

                            @include('includes.flash')
                            @yield('content')                            
                            @include('includes.footer')
                            
                        </div>
                    </div>
                </div>

            </div> <!-- page-container -->
            @else         
            @yield('content')  
            @endif

           
        </div>
        @include('includes.script')
        @yield('scripts')
    </body>
</html>