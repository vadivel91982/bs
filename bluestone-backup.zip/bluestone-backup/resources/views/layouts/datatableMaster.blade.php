<!doctype html>
<html>
    <head>
        @include('includes.head')
    </head>
    <body>
        <div class="page_container">
            
            <div class="container body_content">
                <div id="main">
                 
                    @yield('content')
                </div>
            </div>
            <footer class="">
               
                @yield('scripts')
            </footer>
        </div>
    </body>
</html>